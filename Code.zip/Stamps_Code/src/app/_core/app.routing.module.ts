import {NgModule}  from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderViewComponent } from '../_components/order-view/orderview.component';
import { ServiceViewComponent } from '../_components/service-view/service-view.component';
import { SiteRetrieveComponent } from '../_components/site-view/site-view-sidebar/site-retrieve/site-retrieve.component';
import { OrderRetrieveComponent } from '../_components/order-view/order-view-sidebar/order-retrieve/order-retrieve.component';
import { SiteviewComponent } from '../_components/site-view/siteview.component';
import { LoginComponent } from '../_login/login.component';
import { DashboardComponent } from '../_dashboard/dashboard.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: '', component: LoginComponent },
  { path: 'siteview', component: SiteviewComponent },
  { path: 'orderview', component: OrderViewComponent },
  { path: 'serviceview', component: ServiceViewComponent },
  { path: 'orderRetrieve', component: OrderRetrieveComponent },
  { path: 'siteRetrieve', component: SiteRetrieveComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes,
      { useHash: true })
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }