import { TestBed } from '@angular/core/testing';
import { SiteViewService } from './site-view.service';

describe('SiteViewService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SiteViewService = TestBed.get(SiteViewService);
    expect(service).toBeTruthy();
  });
});
