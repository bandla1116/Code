import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceViewService {

  constructor() { }

  getSeriviceviewTableData() {
    const serviceviewTableData = [{
      migrated: 'Y',
      class: "service",
      subClass : "VSAT",
      status: "In Service",
      Identifier: "",
      customerOrderNumber: "2005I05465A",
      SDPType: "02-FACEPLATE",
      currentDataRate: "CV - 384KBPS (Single Circuit)W/VSAT BACKUP",
      VxBAcceptanceRate: "",
      InstallDate: "05/11/2006",
      ActiveDate: "05/11/2006",
      DisconnectDate: null
    },
    {
      migrated: 'Y',
      class: "service",
      subClass : "VSAT",
      status: "In Service",
      Identifier: "",
      customerOrderNumber: "2005I05465A",
      SDPType: "02-FACEPLATE",
      currentDataRate: "CV - 384KBPS (Single Circuit)W/VSAT BACKUP",
      VxBAcceptanceRate: "",
      InstallDate: "05/11/2006",
      ActiveDate: "05/11/2006",
      DisconnectDate: null
    },
    {
      migrated: 'Y',
      class: "service",
      subClass : "VSAT",
      status: "In Service",
      Identifier: "",
      customerOrderNumber: "2005I05465A",
      SDPType: "02-FACEPLATE",
      currentDataRate: "CV - 384KBPS (Single Circuit)W/VSAT BACKUP",
      VxBAcceptanceRate: "",
      InstallDate: "05/11/2006",
      ActiveDate: "05/11/2006",
      DisconnectDate: null
    },
    {
      migrated: 'Y',
      class: "service",
      subClass : "VSAT",
      status: "In Service",
      Identifier: "",
      customerOrderNumber: "2005I05465A",
      SDPType: "02-FACEPLATE",
      currentDataRate: "CV - 384KBPS (Single Circuit)W/VSAT BACKUP",
      VxBAcceptanceRate: "",
      InstallDate: "05/11/2006",
      ActiveDate: "05/11/2006",
      DisconnectDate: null
    },];
    return serviceviewTableData;
  }
}
