import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './_core/app.routing.module';
import { DashboardComponent } from './_dashboard/dashboard.component';
import { LoginComponent } from './_login/login.component';
import { HttpClient } from '@angular/common/http';
import { GenericModule } from './_components/generic.module';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GenericModule
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
