import { GenericModule } from "./generic.module";


describe('ComponentsModule', () => {
  let genericModule: GenericModule;

  beforeEach(() => {
    genericModule = new GenericModule();
  });

  it('should create an instance', () => {
    expect(genericModule).toBeTruthy();
  });
});
