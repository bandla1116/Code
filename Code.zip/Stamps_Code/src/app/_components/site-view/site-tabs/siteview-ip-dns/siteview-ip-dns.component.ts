import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siteview-ip-dns',
  templateUrl: './siteview-ip-dns.component.html',
  styleUrls: ['./siteview-ip-dns.component.scss']
})
export class SiteviewIpDNSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
