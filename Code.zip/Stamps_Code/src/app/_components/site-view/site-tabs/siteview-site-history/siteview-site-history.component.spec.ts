import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteviewSiteHistoryComponent } from './siteview-site-history.component';

describe('SiteviewSiteHistoryComponent', () => {
  let component: SiteviewSiteHistoryComponent;
  let fixture: ComponentFixture<SiteviewSiteHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteviewSiteHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteviewSiteHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
