import { Component, OnInit } from '@angular/core';
import { SiteViewService } from '../../../../_rest-service/site-view.service';

@Component({
  selector: 'app-siteview-site-history',
  templateUrl: './siteview-site-history.component.html',
  styleUrls: ['./siteview-site-history.component.scss']
})
export class SiteviewSiteHistoryComponent implements OnInit {

  showDetails = false;
  siteHistoryTableData;
  siteHistoryListData;

  getRowDetails(data) {
    console.log(data.User); 
    //  This user ID might have to passed to the
    //   "getSiteHistoryListInfo" and then the 
    //    service might fetch table data
  }

  constructor(private siteSerivice : SiteViewService ) {
    this.siteHistoryTableData = this.siteSerivice.getSiteHistoryInfo();
    this.siteHistoryListData = this.siteSerivice.getSiteHistoryListInfo();
   }

  ngOnInit() {
  }

}
