import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siteview-demarc',
  templateUrl: './siteview-demarc.component.html',
  styleUrls: ['./siteview-demarc.component.scss']
})
export class SiteviewDemarcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
