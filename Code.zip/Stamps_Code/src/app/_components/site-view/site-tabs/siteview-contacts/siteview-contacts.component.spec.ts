import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteviewContactsComponent } from './siteview-contacts.component';

describe('SiteviewContactsComponent', () => {
  let component: SiteviewContactsComponent;
  let fixture: ComponentFixture<SiteviewContactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteviewContactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteviewContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
