import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siteview-contacts',
  templateUrl: './siteview-contacts.component.html',
  styleUrls: ['./siteview-contacts.component.scss']
})
export class SiteviewContactsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
