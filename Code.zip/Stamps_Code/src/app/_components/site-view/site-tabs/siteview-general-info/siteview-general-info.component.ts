import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-siteview-general-info',
  templateUrl: './siteview-general-info.component.html',
  styleUrls: ['./siteview-general-info.component.scss']
})
export class SiteviewGeneralInfoComponent implements OnInit {

  generalInfoForm: FormGroup;
  constructor() { }

  ngOnInit() {
  }

}
