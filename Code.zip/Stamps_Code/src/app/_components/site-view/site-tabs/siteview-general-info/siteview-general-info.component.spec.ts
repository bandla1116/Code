import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteviewGeneralInfoComponent } from './siteview-general-info.component';

describe('SiteviewGeneralInfoComponent', () => {
  let component: SiteviewGeneralInfoComponent;
  let fixture: ComponentFixture<SiteviewGeneralInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteviewGeneralInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteviewGeneralInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
