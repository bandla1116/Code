import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteCommonInfoComponent } from './site-common-info.component';

describe('SiteCommonInfoComponent', () => {
  let component: SiteCommonInfoComponent;
  let fixture: ComponentFixture<SiteCommonInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteCommonInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteCommonInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
