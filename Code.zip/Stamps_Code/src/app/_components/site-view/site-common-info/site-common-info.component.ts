import { Component, OnInit ,Input } from '@angular/core';
import { SiteViewService } from '../../../_rest-service/site-view.service';

@Component({
  selector: 'app-site-common-info',
  templateUrl: './site-common-info.component.html',
  styleUrls: ['./site-common-info.component.scss']
})
export class SiteCommonInfoComponent implements OnInit {

  siteViewInfoList =[];

  constructor(public SiteviewService : SiteViewService ) { }

  // @Input() selectedSiteId: number;
  //This selectedSiteId will be used to fetch the service data later in the code.

  ngOnInit() {
    this.SiteviewService.getSiteCommonInfo().subscribe(data => {
      this.siteViewInfoList = data;
  });
  }


}
