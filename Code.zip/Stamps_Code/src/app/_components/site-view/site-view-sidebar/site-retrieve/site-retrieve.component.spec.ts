import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteRetrieveComponent } from './site-retrieve.component';

describe('SiteRetrieveComponent', () => {
  let component: SiteRetrieveComponent;
  let fixture: ComponentFixture<SiteRetrieveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteRetrieveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteRetrieveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
