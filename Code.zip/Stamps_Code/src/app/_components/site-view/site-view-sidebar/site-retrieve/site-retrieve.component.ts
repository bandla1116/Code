import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-retrieve',
  templateUrl: './site-retrieve.component.html',
  styleUrls: ['./site-retrieve.component.scss']
})
export class SiteRetrieveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
