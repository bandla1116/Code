import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siteview-sidebar',
  templateUrl: './siteview-sidebar.component.html',
  styleUrls: ['./siteview-sidebar.component.scss']
})
export class SiteviewSidebarComponent implements OnInit {

  constructor() { }

  isSidebarActive: boolean = true;

  toggleSidebar(){
    this.isSidebarActive = !this.isSidebarActive;
  }

  ngOnInit() {
  }

}
