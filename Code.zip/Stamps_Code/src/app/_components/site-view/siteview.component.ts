import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { Subject } from 'rxjs';
import {AngularSplitModule} from 'angular-split';
import { HttpClientModule } from '@angular/common/http';
import { GenericService } from '../../_rest-service/generic.service';
import { SiteViewService } from '../../_rest-service/site-view.service';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-siteview',
  templateUrl: './siteview.component.html',
  styleUrls: ['./siteview.component.scss']
})
export class SiteviewComponent implements OnInit {

  rows: any[] = [];
  // selectedSiteID = '';
  showTab = false;
  showCommonInfo = false;

  hideShow(event) { 
    // this.selectedSiteID = siteId;
    this.showCommonInfo = true;
    this.showTab = true;
  }

  constructor(private siteviewService : SiteViewService,
              private genericService : GenericService,
              private route: Router,
              private http: HttpClient ) { }

  exportAsXLSX(tableData):void {
    this.genericService.exportAsExcelFile(tableData, 'SiteView');
  }

  ngOnInit() {
    this.siteviewService.getSiteViewList().subscribe(data => {
      this.rows  = data;
  });
    // this.siteViewList.forEach(element => {
    //   if(element.migratedFlag === "N") {
    //     element.migratedFlag = false;
    //   }
    //   else {
    //     element.migratedFlag = true;
    //   }
    // });   
  }

  onDragEndHandler(event) {
    window.dispatchEvent(new Event('resize'));
  }
 

}
