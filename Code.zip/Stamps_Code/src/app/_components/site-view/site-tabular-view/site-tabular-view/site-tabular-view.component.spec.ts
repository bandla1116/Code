import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteTabularViewComponent } from './site-tabular-view.component';

describe('SiteTabularViewComponent', () => {
  let component: SiteTabularViewComponent;
  let fixture: ComponentFixture<SiteTabularViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteTabularViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteTabularViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
