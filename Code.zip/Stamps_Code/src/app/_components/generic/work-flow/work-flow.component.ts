import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import * as _ from 'lodash';
import { ITreeOptions } from 'angular-tree-component';
import { treeData } from './work-flow.constants';

@Component({
  selector: 'app-work-flow',
  templateUrl: './work-flow.component.html',
  styleUrls: ['./work-flow.component.scss']
})
export class WorkFlowComponent implements OnInit {
  bsModalRef: BsModalRef;
  constructor(private modalService: BsModalService) { }


  openModalWithComponent(event) {
    event.stopPropagation();
    const initialState = {
      list: [
        'Open a modal with component',
        'Pass your data',
        'Do something else',
        '...'
      ],
      title: 'Modal with component'
    };
    this.bsModalRef = this.modalService.show(ModalContentComponent, {initialState});
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  nodes = [];
  

  options: ITreeOptions = {
    idField: 'TASKJOBID',
    displayField: 'NAME',
    childrenField: 'children'
  };

  nodeClickAction(node:any){
    console.log('nodeClicked', node);
  }

  createTreeNode(treeArray){
    for(let i = treeArray.length; i > 0; i--){
      _.forEach(treeArray[i], node => {
        let foundItem = _.find(treeArray[i - 1], item => {
          return item.taskJobId == node.parentTaskId;
        });
        if(foundItem){
          foundItem.children = foundItem.children || [];
          foundItem.children.push(node);
        }
      });
    };
    return treeArray[1];
  }

  transformResponseToTreeFormat(response:any[]){
    let responseLength = response.length;
    let treeLength = 0;
    let treeArray = [];
    let i = 0;
    do {
      treeArray[i] = _.filter(response, res => {
        return res.level == i;
      });
      treeLength = treeLength + treeArray[i].length;
      i++;
    }
    while (treeLength < responseLength);
    return this.createTreeNode(treeArray);
  }

  ngOnInit() {
    this.nodes = this.transformResponseToTreeFormat(treeData);
  }

}

@Component({
  selector: 'modal-content',
  template: `
    <div class="modal-header">
      <h4 class="modal-title pull-left">{{title}}</h4>
      <button type="button" class="close pull-right" aria-label="Close" (click)="bsModalRef.hide()">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <ul *ngIf="list.length">
        <li *ngFor="let item of list">{{item}}</li>
      </ul>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" (click)="bsModalRef.hide()">{{closeBtnName}}</button>
    </div>
  `
})
 
export class ModalContentComponent implements OnInit {
  title: string;
  closeBtnName: string;
  list: any[] = [];
 
  constructor(public bsModalRef: BsModalRef) {}
 
  ngOnInit() {
    this.list.push('PROFIT!!!');
  }
}
