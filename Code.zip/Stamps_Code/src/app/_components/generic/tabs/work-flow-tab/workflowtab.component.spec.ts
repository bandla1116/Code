import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkflowtabComponent } from './workflowtab.component';

describe('WorkflowtabComponent', () => {
  let component: WorkflowtabComponent;
  let fixture: ComponentFixture<WorkflowtabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkflowtabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkflowtabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
