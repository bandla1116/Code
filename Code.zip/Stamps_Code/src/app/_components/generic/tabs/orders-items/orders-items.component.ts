import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-items',
  templateUrl: './orders-items.component.html',
  styleUrls: ['./orders-items.component.scss']
})
export class OrdersItemsComponent implements OnInit {

  rows = [];
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  columns = [
    { name: 'Order Item #', summaryFunc: () => null },
    { name: 'Cust Order #', summaryFunc: () => null },
    { name: 'Service Type', summaryFunc: () => null },
    { name: 'SDP Type', summaryFunc: () => null },
    { name: 'Current Date Rate', summaryFunc: () => null },
    { name: 'Action Type', summaryFunc: () => null },
    { name: 'Primary/Backup', summaryFunc: () => null },
    { name: 'Order Item Status', summaryFunc: () => null },
    { name: 'COMS Number', summaryFunc: () => null },
    { name: 'VzB Circuit ID', summaryFunc: () => null },
    { name: 'FROM-Facility', summaryFunc: () => null }
  ];
  constructor() { }

  ngOnInit() {
  }

}
