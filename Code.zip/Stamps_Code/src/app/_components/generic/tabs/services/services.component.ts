import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {

  rows = [];
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  columns = [
    { name: 'Class', summaryFunc: () => null },
    { name: 'Sub Class', summaryFunc: () => null },
    { name: 'Customer Action Type', summaryFunc: () => null },
    { name: 'Status', summaryFunc: () => null },
    { name: 'Identifier', summaryFunc: () => null },
    { name: 'Customer Order Number', summaryFunc: () => null },
    { name: 'SDP Type', summaryFunc: () => null },
    { name: 'Current Data Rate', summaryFunc: () => null },
    { name: 'VzB Acceptance Date', summaryFunc: () => null },
    { name: 'Install Date', summaryFunc: () => null },
    { name: 'Original VSAT Install Date', summaryFunc: () => null },
    { name: 'Active Date', summaryFunc: () => null },
    { name: 'Disconnect Date', summaryFunc: () => null },
  ];
  constructor() { }

  ngOnInit() {
  }

}
