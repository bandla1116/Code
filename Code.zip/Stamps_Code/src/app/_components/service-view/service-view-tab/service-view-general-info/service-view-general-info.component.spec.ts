import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceViewGeneralInfoComponent } from './serviceviewgeneralinfo.component';

describe('ServiceViewGeneralInfoComponent', () => {
  let component: ServiceViewGeneralInfoComponent;
  let fixture: ComponentFixture<ServiceViewGeneralInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceViewGeneralInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceViewGeneralInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
