import { Component, OnInit } from '@angular/core';
import { GenericService } from '../../_rest-service/generic.service';
import { ServiceViewService } from '../../_rest-service/service-view.service';

@Component({
  selector: 'app-service-view',
  templateUrl: './service-view.component.html',
  styleUrls: ['./service-view.component.scss']
})
export class ServiceViewComponent implements OnInit {

  serviceviewTableData;
  selectedServiceID;
  hideShowFlag: boolean = false;
  hideShowTabFlag: boolean = false;
  generalInfoFlag: boolean= false;

  constructor(private serviceviewService : ServiceViewService, private excelService: GenericService) { }

  exportAsXLSX(tableData):void {
    this.excelService.exportAsExcelFile(tableData, 'serviceview');
  }

  getServiceRowData(serviceID) {
    this.selectedServiceID = serviceID;
    this.hideShowFlag = true;
    this.hideShowTabFlag = true;
  }

  ngOnInit() {
    this.serviceviewTableData = this.serviceviewService.getSeriviceviewTableData();
    this.serviceviewTableData.forEach(element => {
      if(element.migrated === "N") {
        element.migrated = false;
      }
      else {
        element.migrated = true;
      }
    }); 
  }

}
