import {
  Component,
  OnInit,
  ViewChild,
  Input,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter
} from '@angular/core';
import * as _ from 'lodash';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { GenericService } from '../../../_rest-service/generic.service';

@Component({
  selector: 'app-order-tabular-view',
  templateUrl: './order-tabular-view.component.html',
  styleUrls: ['./order-tabular-view.component.scss']
})
export class OrderTabularViewComponent implements OnInit, OnChanges {
  @ViewChild('myTable') table: any;
  // @ViewChild(DatatableComponent) public table: DatatableComponent;
  @Input() tableRows:any;
  // @Input() level:number;
  // @Output() onToggle = new EventEmitter<any>();
  @Output() hideEventEmitter = new EventEmitter<boolean>();
  columnMappingArray:any = {
    'customerOrderNumber' : 'Cus Order Num',
  };
  
  columns: any;
  allColumns: any[];
  selectedItems = [];
  dropdownSettings = {
    singleSelection: false,
    itemsShowLimit: 3,
    allowSearchFilter: false,
    enableCheckAll: false
  };

  public currentPageLimit: number = 10;
  public currentVisible: number = 3;
  public readonly pageLimitOptions = [
    {value: 5},
    {value: 10},
    {value: 25},
    {value: 50},
    {value: 100},
  ];

  constructor( private excelService: GenericService ) {}

  exportAsXLSX(data):void {
    this.excelService.exportAsExcelFile(data, 'OrderTable');
  }

  public onLimitChange(limit: any): void {
    this.changePageLimit(limit);
    this.table.limit = this.currentPageLimit;
    this.table.recalculate();
    setTimeout(() => {
      if (this.table.bodyComponent.temp.length <= 0) {
        // TODO[Dmitry Teplov] find a better way.
        // TODO[Dmitry Teplov] test with server-side paging.
        this.table.offset = Math.floor((this.table.rowCount - 1) / this.table.limit);
        // this.table.offset = 0;
      }
    });
  }

  private changePageLimit(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
  }

  ngOnInit() {
   
  }

  onDetailToggle(event) {
    //console.log('Detail Toggled', event);
  }

  getRowsHeight(childRows){
    return (childRows && childRows.length > 0) ? 20 : childRows.length * 20;
  }

  buildColumns(row){
    let keys = Object.keys(row);
    this.columns = keys.filter((key) => {
      return !Array.isArray(row[key]);
    });
  }

  ngOnChanges(simpleChanges: SimpleChanges){
    this.columns = [
      {name:'Cust Ord No', prop: "customerOrderNumber", flexGrow: 1}, {name:'Order Type'}, {name:'Order State'}, {name: 'Order Receiv Date'},
      {name: 'Req Due Date'}, {name: 'Data Rate'}, {name: 'Prev Data Rate'}, {name: 'Form Facility'}, {name: 'Form Site Id'}, 
      {name: 'From State'}, {name: 'From NPANXX'}, {name: 'From Main Phone'}, {name: 'To Facility'}, {name: 'To Site Id'},
      {name: 'To State'}, {name: 'Order Cat Code'}, {name: 'Req Id'}, {name: 'SDP Type'}, {name: 'Hot Order Ind'}, 
      {name: 'Service Type'}, {name: 'Serice Sub Type'}, {name: 'Bandwidth'}
    ]
    if(simpleChanges.tableRows.currentValue && simpleChanges.tableRows.currentValue.length){
      this.buildColumns(simpleChanges.tableRows.currentValue[0]);
      this.allColumns = this.columns;
      this.selectedItems = this.columns;
      // console.log(this.allColumns);
    }
  }

  rowClick(row) {
    this.hideEventEmitter.emit(true);
  }

  onItemSelect(item: any) {
    // console.log(item);
    this.columns.unshift(item);
  }
  onDeSelect(item: any){
    // console.log(item);
    this.columns = _.filter(this.columns, col => {
      return col !== item;
    });
  }
}