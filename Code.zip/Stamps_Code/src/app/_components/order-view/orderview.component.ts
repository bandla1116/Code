import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { OrderViewService } from '../../_rest-service/order-view.service';
import { GenericService } from '../../_rest-service/generic.service';
import { Order } from './orderview.model';


@Component({
  selector: 'app-orderview',
  templateUrl: './orderview.component.html',
  styleUrls: ['./orderview.component.scss']
})
export class OrderViewComponent implements OnInit {
  hideShowTabFlag: boolean = false;
  hideShowFlag: boolean = false;
  public orderListResponse: Order[];
  rows: any[] = [];

  constructor(private orderViewService: OrderViewService,
              private genericService: GenericService,
              private route: Router,
              private http: HttpClient) { }

  exportAsXLSX(tableData): void {
    this.genericService.exportAsExcelFile(tableData, 'OrderView');
  }

  //On init setting some data
  ngOnInit() {
    this.http.get<any[]>('http://demo0457679.mockable.io/order-details')
      .subscribe(response => {
        console.log(response);
        this.rows = response;
      })
  }

  onDragEndHandler(event) {
    window.dispatchEvent(new Event('resize'));
  }

  hideShow(event) {
    this.hideShowFlag = event;
    this.hideShowTabFlag = true;
  }
}
