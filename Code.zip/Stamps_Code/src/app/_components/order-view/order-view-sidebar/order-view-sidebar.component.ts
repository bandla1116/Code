import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-view-sidebar',
  templateUrl: './order-view-sidebar.component.html',
  styleUrls: ['./order-view-sidebar.component.scss']
})
export class OrderviewSidebarComponent implements OnInit {

  constructor( private route : Router) { }

  isSidebarActive: boolean = true;

  toggleSidebar(){
    this.isSidebarActive = !this.isSidebarActive;
  }

  getOrderDetails() {
    this.route.navigate(['/order-details']);
  }

  ngOnInit() {
  }

}
