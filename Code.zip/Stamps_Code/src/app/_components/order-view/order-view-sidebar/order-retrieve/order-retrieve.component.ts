import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-retrieve',
  templateUrl: './order-retrieve.component.html',
  styleUrls: ['./order-retrieve.component.scss']
})
export class OrderRetrieveComponent implements OnInit {

  custOrderCategoryList= {    
    custOrderCategory: 
    [
      { key: 'feed', value: 'FEED'},
      { key: 'rbcs', value: 'RBCS'},
      { key: 'specialOrder', value: 'SPECIAL ORDER'},
      { key: 'uspsNetworkInfra', value: 'USPS NETWORK INFRASTRUCTURE'},
      { key: 'admin', value: 'ADMIN'},
      { key: 'temOrder', value: 'TEM Order'},
      { key: 'zeosOrder', value: 'ZEOS ORDER'}
    ]
  }

  public temServiceType = [{
    Record: {
        Pre: 1,
        prefname: 'cat 1'
    }
  },
  {
    Record: {
        Pre: 2,
        prefname: 'cat 2'
    }
  },
  {
    Record: {
        Pre: 3,
        prefname: 'cat 3'
    }
  },
  ];
  constructor() { }

  ngOnInit() {
  }

}
