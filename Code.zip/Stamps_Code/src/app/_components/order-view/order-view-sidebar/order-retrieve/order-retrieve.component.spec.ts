import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderRetrieveComponent } from './order-retrieve.component';

describe('OrderRetrieveComponent', () => {
  let component: OrderRetrieveComponent;
  let fixture: ComponentFixture<OrderRetrieveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderRetrieveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderRetrieveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
