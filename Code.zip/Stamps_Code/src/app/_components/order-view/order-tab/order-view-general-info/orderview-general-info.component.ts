import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl} from '@angular/forms';
import { OrderViewService } from '../../../../_rest-service/order-view.service';

@Component({
  selector: 'app-orderview-general-info',
  templateUrl: './orderview-general-info.component.html',
  styleUrls: ['./orderview-general-info.component.scss']
})
export class OrderviewGeneralInfoComponent implements OnInit {

  // generalInfo: { "temInfo": { "temId": number; "requestId": number; "uspsWorkStatus": string; "expediteRequestIndicator": any; "vendor": string; "paymentContractAccount": string; "demarc": any; "technicianEmail": string; "uspsIsManagerName": string; "uspsIsManagerPhone": string; "uspsPriContactName": string; "uspsPriContactPhone": string; "uspsAltContactName": string; "uspsAltContactPhone": string; "billDirectIndicator": string; "billDirectSiteId": any; "billContactName": any; "billContactPhone": any; "billLocationName": any; "billLocationAddress1": any; "billLocationCity": any; "billLocationState": any; "billLocationZipcode": any; "billDeliveryOrderNumber": any; "serviceType": string; "serviceSubtype": any; "serviceIdentifier": string; "circuitId": any; "networkServiceProvider": any; "deviceName": any; "ipAddressRequest": string; "lanIpAddress": any; "lanIpSubnet": any; "wanIp": any; "wanSubnet": any; "primaryDns": any; "secondaryDns": any; "wanSpeed": any; "lanSpeed": any; "lanDuplex": any; "ipHelper": any; "ipType": any; "oobPhoneNumber": any; "specialInstructions": string; }; "ordInfo": { "custReqDueDate": string; "customerRequestNum": string; "customerOrderType": string; "methodRecieved": string; "state": string; "custProjectId": any; "projectId": any; "corpDueDate": any; "actualCompletionDate": any; "customerExpediteFlag": string; "corpExpediteFlag": string; "orderReceivedDate": string; "createDate": string; "gmBillingStopDate": any; "gmBillingStartDate": any; "vendorInstructions": string; "dateSoAuthorized": any; "authorizedByName": string; "orderCategoryCode": string; "custCancelIndicator_code": string; "uspsApplicationCode": string; "uspsPhaseCode": string; "uspsSiteCategoryCode": string; "dataRateCode": string; "prevDataRateCode": string; "siteTypeCode": string; "sdpTypeCode": string; "numDrop": any; "numAddlDrop": any; "numEnetPort": any; "numAddlEnetPort": any; "aoiDeploymentCode": string; "aoiDepCode": string; "prnCode": string; "wiringCode": string; "ipAddressReqCode": string; }; };
  generalInfo: any;
  constructor( private OrderviewService : OrderViewService) {
   
  }
  getGeneralInfo() {
    this.OrderviewService.getOrderGeneralInfo().subscribe(value => {
      if(value)
      this.generalInfo = value;
   });
  }
  ngOnInit() {
   this.getGeneralInfo();
  }

}
