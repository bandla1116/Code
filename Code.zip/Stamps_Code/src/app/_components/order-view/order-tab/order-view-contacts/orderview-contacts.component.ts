import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderview-contacts',
  templateUrl: './orderview-contacts.component.html',
  styleUrls: ['./orderview-contacts.component.scss']
})
export class OrderviewContactsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
