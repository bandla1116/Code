import { Component, OnInit } from '@angular/core';
import { OrderViewService } from '../../../../_rest-service/order-view.service';

@Component({
  selector: 'app-orderview-clins',
  templateUrl: './orderview-clins.component.html',
  styleUrls: ['./orderview-clins.component.scss']
})
export class OrderviewClinsComponent implements OnInit {
  
  orderClinsData :any;
  proposalClinsData :any;
  serviceClinsData :any;

  constructor( private OrderviewService : OrderViewService) {
  }

  getClinsInfo() {
    this.OrderviewService.getClinsInfo().subscribe(clinsData => {
      this.orderClinsData  = clinsData.clins;
      this.proposalClinsData = clinsData.proposalClins;
      this.serviceClinsData  = clinsData.serviceClins;
    });

  }

  ngOnInit() {
    this.getClinsInfo();
  }

}
