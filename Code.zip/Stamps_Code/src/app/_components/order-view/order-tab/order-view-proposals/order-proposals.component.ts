import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-proposals',
  templateUrl: './order-proposals.component.html',
  styleUrls: ['./order-proposals.component.scss']
})
export class OrderProposalsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
