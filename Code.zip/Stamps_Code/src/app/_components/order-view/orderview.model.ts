export class Order {
    customerOrderNumber: string;
    orderType: string;
    orderState: string;
    orderReceivedDate: string;
    reqDueDate: string;
    dataRate: string;
    prevDataRate: string;
    fromFacility: string;
    fromSiteId: string;
    fromState: string;
    fromNpanxx: string;
    fromMainPhone: string;
    toFacility: string;
    toSiteId: string;
    toState: string;
    orderCategoryCode: string;
    requestId: string;
    sdpType: string;
    hotOrderInd: string;
    serviceType: string;
    serviceSubType: string;
    bandwidth: string;
  }