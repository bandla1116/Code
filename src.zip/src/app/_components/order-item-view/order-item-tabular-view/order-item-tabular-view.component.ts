import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { GenericService } from '../../../_rest-service/generic.service';
import { FilterService } from '../../../_rest-service/filter.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-order-item-tabular-view',
  templateUrl: './order-item-tabular-view.component.html',
  styleUrls: ['./order-item-tabular-view.component.scss']
})
export class OrderItemTabularViewComponent implements OnInit {
  @ViewChild('myTable') table: any;
  @Input() tableRows:any;
  @Output() hideEventEmitter = new EventEmitter<boolean>();
  @Output() selectedRow = new EventEmitter<any>();
  @Output() selectedID = new EventEmitter<any>();
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  private rawTableRows:any[] = [];
  private filterProps:any[] = [];
  private filterSearchKeys:any = {};
  columns : any[];
  allColumns: any[];
  selectedItems = [];
  selected = [];
  dropdownSettings = {
    singleSelection: false,
    itemsShowLimit: 3,
    allowSearchFilter: false,
    enableCheckAll: false,
    idField: 'id',
    textField: 'name'
  };
  public currentPageLimit: number = 10;
  public currentVisible: number = 3;
  public readonly pageLimitOptions = [
    {value: 5},
    {value: 10},
    {value: 25},
    {value: 50},
    {value: 100},
  ];

  redifinedColumns = 
  [
    {
      id : 'hotOrderInd',
      name : 'Hot',
      priority : 1
    },
    {
      id : 'customerOrderNumber',
      name : 'Customer Ord #',
      priority : 2
    },
    {
      id : 'orderCategoryCode',
      name : 'Order Cat Code',
      priority : 3
    },
    {
      id : 'orderType',
      name : 'Cust Action Type',
      priority : 4
    },
    {
      id : 'orderState',
      name : 'Order Status',
      priority : 5
    },
    {
      id : 'fromFacility',
      name : 'From-Facility Name',
      priority : 6
    },
    {
      id : 'fromState',
      name : 'From State',
      priority : 7
    },
    {
      id : 'fromSiteId',
      name : 'From Site Id',
      priority : 8
    },
    {
      id : 'toFacility',
      name : 'To Facility',
      priority : 9
    },
    {
      id : 'toState',
      name : 'To State',
      priority : 10
    },
    {
      id : 'toSiteId',
      name : 'To Site Id',
      priority : 11
    },
    {
      id : 'orderReceivedDate',
      name : 'Order Received Date',
      priority : 12
    },
    {
      id : 'reqDueDate',
      name : 'Req Due Date',
      priority : 13
    },
    {
      id : 'serviceType',
      name : 'Service Type',
      priority : 14
    },
    {
      id : 'bandwidth',
      name : 'Bandwidth',
      priority : 15
    },
    {
      id : 'sdpType',
      name : 'SDP Type',
      priority : 16
    },
    {
      id : 'dataRate',
      name : 'Data Rate',
      priority : 17
    },
    {
      id : 'prevDataRate',
      name : 'Prev Data Rate',
      priority : 18
    },
    {
      id : 'fromNpanxx',
      name : 'From NPANXX',
      priority : 19
    },
    {
      id : 'fromMainPhone',
      name : 'From Main Phone',
      priority : 20
    }
  ]

  constructor(private excelService: GenericService,
    private filterService: FilterService) { }

    exportAsXLSX(data):void {
      this.excelService.exportAsExcelFile(data, 'SiteTable');
    }

    public onLimitChange(limit: any): void {
      this.currentPageLimit = parseInt(limit, 10);
    }

    private changePageLimit(limit: any): void {
      this.currentPageLimit = parseInt(limit, 10);
    }
  
    onDetailToggle(event) {
      //console.log('Detail Toggled', event);
    }
  
    getRowsHeight(childRows){
      return (childRows && childRows.length > 0) ? 20 : childRows.length * 20;
    }

  ngOnInit() {
  }

  ngOnChanges(simpleChanges: SimpleChanges){
    if(simpleChanges.tableRows.currentValue && simpleChanges.tableRows.currentValue.length){
       this.rawTableRows = simpleChanges.tableRows.currentValue;
      // this.buildColumns(simpleChanges.tableRows.currentValue[0]);
      this.redifinedColumns.sort((a, b) => {
        // if(!this.columnOrder[a] || !this.columnOrder[b]) return 0;
        let valuea = a.priority ? a.priority+'': 'z';
        let valueb = b.priority ? b.priority+'': 'z';
        return valuea.localeCompare(valueb);
      });
      this.selectedItems = this.allColumns = this.redifinedColumns;
    }
  }

  rowClick(row) { 
  }

  onSelect({selected}) {
    this.hideEventEmitter.emit(true);
    this.selectedRow.emit(selected[0]);
  }

  onItemSelect(item: any) {
    // console.log(item);
    this.redifinedColumns.unshift(item);
  }

  onDeSelect(item: any){
    // console.log(item);
    this.redifinedColumns = _.filter(this.redifinedColumns, col => {
      return col.id !== item.id;
    });
  }

  onFilterChange(colName, colValue){
    let filterProp = _.find(this.filterProps, prop=>{
      return colName == prop;
    });
    this.filterSearchKeys[colName] = colValue;
    if(!colValue){
      _.remove(this.filterProps, prop => {
        return prop == colName;
      });
      delete this.filterSearchKeys[colName];
    }else if(!filterProp){
      this.filterProps.push(colName);
    }
    this.tableRows = this.filterService.filterItems(this.rawTableRows, this.filterProps, this.filterSearchKeys)
  }

}
