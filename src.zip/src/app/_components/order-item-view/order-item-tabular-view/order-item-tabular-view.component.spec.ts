import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderItemTabularViewComponent } from './order-item-tabular-view.component';

describe('OrderItemTabularViewComponent', () => {
  let component: OrderItemTabularViewComponent;
  let fixture: ComponentFixture<OrderItemTabularViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderItemTabularViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderItemTabularViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
