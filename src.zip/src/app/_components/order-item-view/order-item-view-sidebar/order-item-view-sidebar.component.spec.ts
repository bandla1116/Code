import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderItemViewSidebarComponent } from './order-item-view-sidebar.component';

describe('OrderItemViewSidebarComponent', () => {
  let component: OrderItemViewSidebarComponent;
  let fixture: ComponentFixture<OrderItemViewSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderItemViewSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderItemViewSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
