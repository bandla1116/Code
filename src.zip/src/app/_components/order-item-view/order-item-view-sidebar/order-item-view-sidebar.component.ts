import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { OrderNewModalComponent } from '../../order-view/order-view-sidebar/order-new-modal/order-new-modal.component';
import { SupplementModificationModalComponent } from '../../order-view/order-view-sidebar/supplement-modification-modal/supplement-modification-modal.component';
import { OrderCancelModalComponent } from '../../order-view/order-view-sidebar/order-cancel-modal/order-cancel-modal.component';

@Component({
  selector: 'app-order-item-view-sidebar',
  templateUrl: './order-item-view-sidebar.component.html',
  styleUrls: ['./order-item-view-sidebar.component.scss']
})
export class OrderItemViewSidebarComponent implements OnInit {
  generalInfo: any;
  generalInfoForm: FormGroup;
  bsModalRef: BsModalRef;
  
  constructor(private route : Router, private modalService : BsModalService) { }

  ngOnInit() {
  }
  isSidebarActive: boolean = true;

  toggleSidebar(){
    this.isSidebarActive = !this.isSidebarActive;
  }

  getOrderDetails() {
    this.route.navigate(['/order-details']);
  }

  openModalWithComponent(event) {
    event.stopPropagation();
 
    this.bsModalRef = this.modalService.show(OrderNewModalComponent);
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  openSupplementModificationModalWithComponent(event) {
    event.stopPropagation();
 
    this.bsModalRef = this.modalService.show(SupplementModificationModalComponent);
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  openCancelOrderModalWithComponent(event) {
    event.stopPropagation();
 
    this.bsModalRef = this.modalService.show(OrderCancelModalComponent);
    this.bsModalRef.content.closeBtnName = 'Close';
  }
}
