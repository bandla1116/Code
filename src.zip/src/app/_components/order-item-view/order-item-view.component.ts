import { Component, OnInit } from '@angular/core';
import { Order } from '../order-view/orderview.model';
import { GenericService } from '../../_rest-service/generic.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { OrderService } from '../order-view/order-service/order.service';

@Component({
  selector: 'app-order-item-view',
  templateUrl: './order-item-view.component.html',
  styleUrls: ['./order-item-view.component.scss']
})
export class OrderItemViewComponent implements OnInit {
  hideShowTabFlag: boolean = false;
  hideShowFlag: boolean = false;
  public orderListResponse: Order[];
  rows: any[] = [];
  constructor(private orderService: OrderService,
    private genericService: GenericService,
    private route: Router,
    private http: HttpClient) { }

    exportAsXLSX(tableData): void {
      this.genericService.exportAsExcelFile(tableData, 'OrderView');
    }

    ngOnInit() {
      this.http.get<any[]>('http://demo0457679.mockable.io/order-details')
      .subscribe(response => {
        console.log(response);
        this.rows = response;
      });
    }

    onDragEndHandler(event) {
      window.dispatchEvent(new Event('resize'));
    }
  
    hideShow(event) {
      this.hideShowFlag = event;
      this.hideShowTabFlag = true;
    }
}
