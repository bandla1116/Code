import {
  Component,
  OnInit,
  ViewChild,
  Input,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter
} from '@angular/core';
import * as _ from 'lodash';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { GenericService } from '../../../_rest-service/generic.service';
import { FilterService } from '../../../_rest-service/filter.service';

@Component({
  selector: 'app-order-tabular-view',
  templateUrl: './order-tabular-view.component.html',
  styleUrls: ['./order-tabular-view.component.scss']
})
export class OrderTabularViewComponent implements OnInit, OnChanges {
  @ViewChild('myTable') table: any;
  // @ViewChild(DatatableComponent) public table: DatatableComponent;
  @Input() tableRows:any;
  // @Input() level:number;
  // @Output() onToggle = new EventEmitter<any>();
  @Output() hideEventEmitter = new EventEmitter<boolean>();
  @Output() selectedRow = new EventEmitter<any>();
  @Output() columnsList = new EventEmitter<any>();
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  isShowColName: boolean = false;
  columnHeaders={};
  loading: boolean = false;
  columnMap: any = {
    'hotOrderInd': 'Hot',
    'customerOrderNumber' : 'Cus Order #',
    'orderCategoryCode': 'Order Cat Code',
    'orderType': 'Cust Action Type',
    'orderState': 'Order Status',
    'fromFacility': 'From-Facility Name',
    'fromState': 'From State',
    'fromSiteId': 'From Site Id',
    'toFacility': 'To Facility',
    'toState': 'To State',
    'toSiteId': 'To Site Id',
    'orderReceivedDate': 'Order Received Date',
    'reqDueDate': 'Req Due Date',
    'serviceType': 'Service Type',
    'bandwidth': 'Bandwidth',
    'sdpType': 'SDP Type',
    'dataRate': 'Data Rate',
    'prevDataRate': 'Prev Data Rate',
    'fromNpanxx': 'From NPANXX',
    'fromMainPhone': 'From Main Phone'
  };
  
  private rawTableRows:any[] = [];
  private filterProps:any[] = [];
  private filterSearchKeys:any = {};
  columns: any;
  allColumns: any[];
  selectedItems = [];
  selected = [];
  dropdownSettings = {
    singleSelection: false,
    itemsShowLimit: 3,
    allowSearchFilter: false,
    enableCheckAll: false,
    idField: 'id',
    textField: 'name'
  };

  public currentPageLimit: number = 10;
  public currentVisible: number = 3;
  public readonly pageLimitOptions = [
    {value: 5},
    {value: 10},
    {value: 25},
    {value: 50},
    {value: 100},
  ];

  redifinedColumns = 
  [
    {
      id : 'hotOrderInd',
      name : 'Hot',
      priority : 1
    },
    {
      id : 'customerOrderNumber',
      name : 'Customer Order #',
      priority : 10
    },
    {
      id : 'orderCategoryCode',
      name : 'Order Category Code',
      priority : 11
    },
    {
      id : 'orderType',
      name : 'Customer Action Type',
      priority : 4
    },
    {
      id : 'orderState',
      name : 'Order Status',
      priority : 5
    },
    {
      id : 'fromFacility',
      name : 'From-Facility Name',
      priority : 6
    },
    {
      id : 'fromState',
      name : 'From State',
      priority : 7
    },
    {
      id : 'fromSiteId',
      name : 'From Site Id',
      priority : 8
    },
    {
      id : 'toFacility',
      name : 'To Facility',
      priority : 9
    },
    {
      id : 'toState',
      name : 'To State',
      priority : 2
    },
    {
      id : 'toSiteId',
      name : 'To Site Id',
      priority : 3
    },
    {
      id : 'orderReceivedDate',
      name : 'Order Received Date',
      priority : 12
    },
    {
      id : 'reqDueDate',
      name : 'Req Due Date',
      priority : 13
    },
    {
      id : 'serviceType',
      name : 'Service Type',
      priority : 14
    },
    {
      id : 'bandwidth',
      name : 'Bandwidth',
      priority : 15
    },
    {
      id : 'sdpType',
      name : 'SDP Type',
      priority : 16
    },
    {
      id : 'dataRate',
      name : 'Data Rate',
      priority : 17
    },
    {
      id : 'prevDataRate',
      name : 'Prev Data Rate',
      priority : 18
    },
    {
      id : 'fromNpanxx',
      name : 'From NPANXX',
      priority : 19
    },
    {
      id : 'fromMainPhone',
      name : 'From Main Phone',
      priority : 20
    },
  ]

  private columnOrder = {
    customerOrderNumber : 2,
    dataRate : 3,
    fromSiteId : 1  
  };

  constructor( private excelService: GenericService, 
               private filterService: FilterService ) {}

  exportAsXLSX(data):void {
    this.excelService.exportAsExcelFile(data, 'OrderTable');
  }

  public onLimitChange(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
  }

  ngOnInit() {
   
  }

  private changePageLimit(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
  }

  onDetailToggle(event) {
    //console.log('Detail Toggled', event);
  }

  getRowsHeight(childRows){
    return (childRows && childRows.length > 0) ? 20 : childRows.length * 20;
  }

  ignoreColumns=[
    // 'customerOrderNumber'
  ];

  buildColumns(row){
    let keys = Object.keys(row);
    this.columns = keys.filter((key) => {
      return !Array.isArray(row[key])
     });
    console.log('keys 111 [',keys);
  }

  ngOnChanges(simpleChanges: SimpleChanges){
    this.columns = []
    if(simpleChanges.tableRows.currentValue && simpleChanges.tableRows.currentValue.length){
      // this.buildColumns(simpleChanges.tableRows.currentValue[0]);
      this.rawTableRows = simpleChanges.tableRows.currentValue;
      // this.columns.sort((a, b) => {
      //   let valuea = this.columnOrder[a] ? this.columnOrder[a]+'': 'z';
      //   let valueb = this.columnOrder[b] ? this.columnOrder[b]+'': 'z';
      //   return valuea.localeCompare(valueb);
      // });
      // this.allColumns = this.columns;
      // this.selectedItems = this.columns;
      // this.rawTableRows = simpleChanges.tableRows.currentValue;
      // console.log(this.allColumns);

      this.redifinedColumns.sort((a, b) => {
        // if(!this.columnOrder[a] || !this.columnOrder[b]) return 0;
        let valuea = a.priority ? a.priority+'': 'z';
        let valueb = b.priority ? b.priority+'': 'z';
        return valuea.localeCompare(valueb);
      });
      this.selectedItems = this.allColumns = this.redifinedColumns;
    }
  }

  rowClick(row) {
    this.hideEventEmitter.emit(true);
  }

  onItemSelect(item: any) {
    // console.log(item);
    // this.columns.unshift(item);
    this.redifinedColumns.unshift(item);
  }
  onDeSelect(item: any){
    // console.log(item);
    // this.columns = _.filter(this.columns, col => {
    //   return col !== item;
    // });
    this.redifinedColumns = _.filter(this.redifinedColumns, col => {
      return col.id !== item.id;
    });
  }
  onSelect({selected}) {
    // console.log('Select event', selected, this.selected);
    // this.hideEventEmitter.emit(true);
    // this.excelService.customerOrderNumber = selected[0].customerOrderNumber;
    this.hideEventEmitter.emit(true);
    this.selectedRow.emit(selected[0]);
    
    var testing =[];
    for(var value in this.columnMap) {
      _.forEach(this.columns,function(items,key) {
      
          if(value === items) {
            testing.push(items);
          }
      });
  };
  this.columnsList.emit(testing);
  }

  onFilterChange(colName, colValue){
    let filterProp = _.find(this.filterProps, prop=>{
      return colName == prop;
    });
    this.filterSearchKeys[colName] = colValue;
    if(!colValue){
      _.remove(this.filterProps, prop => {
        return prop == colName;
      });
      delete this.filterSearchKeys[colName];
    }else if(!filterProp){
      this.filterProps.push(colName);
    }
    this.tableRows = this.filterService.filterItems(this.rawTableRows, this.filterProps, this.filterSearchKeys)
  }
}