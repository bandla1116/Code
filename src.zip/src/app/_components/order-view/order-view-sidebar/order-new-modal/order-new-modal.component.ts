import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-new-modal',
  templateUrl: './order-new-modal.component.html',
  styleUrls: ['./order-new-modal.component.css']
})
export class OrderNewModalComponent implements OnInit {

  public showActionSelect: boolean = false;
  public currentChoice: string = "";

  public categoryOptions = [
    {value: ""},
    {value: "RBCS"},
    {value: "Special Order"},
    {value: "USPS Network Infrastructure"},
    {value: "ADMIN"}
  ]

  public actionOptions = [
    {value: "Change"},
    {value: "Initiate"},
    {value: "Terminate"}
  ]

  closeBtnName: "Close";
  list: any[] = [];

  constructor(public bsModalRef: BsModalRef, public route: Router) {}

  navigate() {
    this.bsModalRef.hide();
    this.route.navigate(['/orderNew']);
  }

  categoryModelChanged($event) {
    this.showActionSelect = true;
  }

  ngOnInit() {
  }
}