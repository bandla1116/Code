import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderNewModalComponent } from './order-new-modal.component';

describe('OrderNewModalComponent', () => {
  let component: OrderNewModalComponent;
  let fixture: ComponentFixture<OrderNewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderNewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderNewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
