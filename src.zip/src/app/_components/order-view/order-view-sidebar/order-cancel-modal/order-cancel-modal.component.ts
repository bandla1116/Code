import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';

@Component({
  selector: 'app-order-cancel-modal',
  templateUrl: './order-cancel-modal.component.html',
  styleUrls: ['./order-cancel-modal.component.css']
})
export class OrderCancelModalComponent implements OnInit {

  closeBtnName: "Close";
  list: any[] = [];
 
  constructor(public bsModalRef: BsModalRef) {}
 
  ngOnInit() {
  }
}
