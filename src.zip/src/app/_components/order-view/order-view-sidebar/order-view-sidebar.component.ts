import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { OrderNewModalComponent } from './order-new-modal/order-new-modal.component';
import { SupplementModificationModalComponent } from './supplement-modification-modal/supplement-modification-modal.component';
import { OrderCancelModalComponent } from './order-cancel-modal/order-cancel-modal.component';


@Component({
  selector: 'app-order-view-sidebar',
  templateUrl: './order-view-sidebar.component.html',
  styleUrls: ['./order-view-sidebar.component.scss']
})
export class OrderviewSidebarComponent implements OnInit {
  generalInfo: any;
  generalInfoForm: FormGroup;
  bsModalRef: BsModalRef;

  constructor( private route : Router, private modalService : BsModalService) { }

  isSidebarActive: boolean = true;

  toggleSidebar(){
    this.isSidebarActive = !this.isSidebarActive;
  }

  getOrderDetails() {
    this.route.navigate(['/order-details']);
  }

  openModalWithComponent(event) {
    event.stopPropagation();
 
    this.bsModalRef = this.modalService.show(OrderNewModalComponent);
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  openSupplementModificationModalWithComponent(event) {
    event.stopPropagation();
 
    this.bsModalRef = this.modalService.show(SupplementModificationModalComponent);
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  openCancelOrderModalWithComponent(event) {
    event.stopPropagation();
 
    this.bsModalRef = this.modalService.show(OrderCancelModalComponent);
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  ngOnInit() {
  }

}
