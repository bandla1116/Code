import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderviewSidebarComponent } from './orderview-sidebar.component';

describe('OrderviewSidebarComponent', () => {
  let component: OrderviewSidebarComponent;
  let fixture: ComponentFixture<OrderviewSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderviewSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderviewSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
