import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';

@Component({
  selector: 'app-supplement-modification-modal',
  templateUrl: './supplement-modification-modal.component.html',
  styleUrls: ['./supplement-modification-modal.component.css']
})
export class SupplementModificationModalComponent implements OnInit {

  closeBtnName: "Close";
  list: any[] = [];
 
  constructor(public bsModalRef: BsModalRef) {}
 
  ngOnInit() {
  }
}
