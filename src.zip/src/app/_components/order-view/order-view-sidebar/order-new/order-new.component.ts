import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-order-new',
  templateUrl: './order-new.component.html',
  styleUrls: ['./order-new.component.css']
})
export class OrderNewComponent implements OnInit {

  public customerExpedite: any = undefined;

  public customerExpediteEvent($event) {
    this.customerExpedite = (event.target as HTMLInputElement).value;
    console.log(this.customerExpedite);
  }
  public customerProjectNames = [
    {value: ""},
    {value: "Choice A"},
    {value: "Choice B"},
    {value: "Choice C"},
    {value: "Choice D"},
    {value: "Choice E"}
  ]

  public customerOrderReceiptMethods = [
    {value: ""},
    {value: "Data Feed"},
    {value: "E-mail"},
    {value: "Fax"},
    {value: "STAMPS Order Entry"},
    {value: "Voice"}
  ]

  public verizonProjectNames = [
    {value:""},
    {value:"Choice A"},
    {value:"Choice B"},
    {value:"Choice C"},
    {value:"Choice D"},
    {value:"Choice E"}
  ]
  constructor() { }

  ngOnInit() {
  }

}
