import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderviewClinsComponent } from './orderview-clins.component';

describe('OrderviewClinsComponent', () => {
  let component: OrderviewClinsComponent;
  let fixture: ComponentFixture<OrderviewClinsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderviewClinsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderviewClinsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
