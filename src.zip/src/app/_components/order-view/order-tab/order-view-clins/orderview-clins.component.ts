import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../order-service/order.service';

@Component({
  selector: 'app-orderview-clins',
  templateUrl: './orderview-clins.component.html',
  styleUrls: ['./orderview-clins.component.scss']
})
export class OrderviewClinsComponent implements OnInit {
  
  orderClinsData :any;
  proposalClinsData :any;
  serviceClinsData :any;

  constructor( private orderService : OrderService) {
  }

  getClinsInfo() {
    this.orderService.getClinsInfo().subscribe(clinsData => {
      this.orderClinsData  = clinsData.clins;
      this.proposalClinsData = clinsData.proposalClins;
      this.serviceClinsData  = clinsData.serviceClins;
    });

  }

  ngOnInit() {
    this.getClinsInfo();
  }

}
