import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderviewGeneralInfoComponent } from './orderview-general-info.component';

describe('OrderviewGeneralInfoComponent', () => {
  let component: OrderviewGeneralInfoComponent;
  let fixture: ComponentFixture<OrderviewGeneralInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderviewGeneralInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderviewGeneralInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
