import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl} from '@angular/forms';
import { OrderService } from '../../order-service/order.service';

@Component({
  selector: 'app-orderview-general-info',
  templateUrl: './orderview-general-info.component.html',
  styleUrls: ['./orderview-general-info.component.scss']
})
export class OrderviewGeneralInfoComponent implements OnInit {

  generalInfo: any;
  constructor( private orderService : OrderService) {
   
  }
  getGeneralInfo() {
    this.orderService.getOrderGeneralInfo().subscribe(value => {
      if(value)
      this.generalInfo = value;
   });
  }
  ngOnInit() {
   this.getGeneralInfo();
  }

}
