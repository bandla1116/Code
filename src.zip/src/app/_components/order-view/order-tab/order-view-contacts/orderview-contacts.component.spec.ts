import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderviewContactsComponent } from './orderview-contacts.component';

describe('OrderviewContactsComponent', () => {
  let component: OrderviewContactsComponent;
  let fixture: ComponentFixture<OrderviewContactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderviewContactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderviewContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
