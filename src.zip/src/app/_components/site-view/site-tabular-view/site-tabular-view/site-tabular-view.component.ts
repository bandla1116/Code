import {
  Component,
  OnInit,
  ViewChild,
  Input,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter
} from '@angular/core';
import * as _ from 'lodash';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { GenericService } from '../../../../_rest-service/generic.service';
import { FilterService } from '../../../../_rest-service/filter.service';

@Component({
  selector: 'app-site-tabular-view',
  templateUrl: './site-tabular-view.component.html',
  styleUrls: ['./site-tabular-view.component.scss']
})
export class SiteTabularViewComponent implements OnInit, OnChanges {

  @ViewChild('myTable') table: any;
  // @ViewChild(DatatableComponent) public table: DatatableComponent;
  @Input() tableRows:any;
  // @Input() level:number;
  // @Output() onToggle = new EventEmitter<any>();
  @Output() hideEventEmitter = new EventEmitter<boolean>();
  @Output() selectedRow = new EventEmitter<any>();
  @Output() columnsList = new EventEmitter<any>();
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  isShowColName: boolean = false;
  columnHeaders={};
  loading: boolean = false;

  columnMap: any = {
    'siteOldCustomerSiteId' : "Site Cust ID",
    'siteId':"Site ID",
      "siteCustomerSiteId": "USPS Site ID",
      "siteIdentifierType": "Site Type",
      "migratedFlag": "Migrated",
      "siteIdentifier": "Facility Name",
      "addressCity": "City",
      "addressState": "State",
      "addressZip": "Zip Code",
      "siteStampsDistrict": "District",
      "siteStampsPvp": "PVP",
      "fdbId": "FDB ID"
  };
  private rawTableRows:any[] = [];
  private filterProps:any[] = [];
  private filterSearchKeys:any = {};
  columns : any[];
  allColumns: any[];
  selectedItems = [];
  selected = [];
  dropdownSettings = {
    singleSelection: false,
    itemsShowLimit: 3,
    allowSearchFilter: false,
    enableCheckAll: false,
    idField: 'id',
    textField: 'name'
  };

  public currentPageLimit: number = 10;
  public currentVisible: number = 3;
  public readonly pageLimitOptions = [
    {value: 5},
    {value: 10},
    {value: 25},
    {value: 50},
    {value: 100},
  ];
  redifinedColumns = 
  [
    {
      id : 'siteCustomerSiteId',
      name : 'USPS Site ID',
      priority : 1
    },
    {
      id : 'migratedFlag',
      name : 'Migrated',
      priority : 2
    },
    {
      id : 'siteIdentifierType',
      name : 'Site Type',
      priority : 3
    },
    {
      id : 'fdbId',
      name : 'FBD ID',
      priority : 4
    },
    {
      id : 'siteIdentifier',
      name : 'Facility Name',
      priority : 5
    },
    {
      id : 'addressCity',
      name : 'City',
      priority : 6
    },
    {
      id : 'addressState',
      name : 'State',
      priority : 7
    },
    {
      id : 'siteIdentifierType',
      name : 'Site Type',
      priority : 8
    },
    {
      id : 'addressZip',
      name : 'ZIP Code',
      priority : 9
    },
    // {
    //   id : 'siteStampsPvp',
    //   name : 'PVP',
    //   priority : 10
    // },
  ]

  constructor( private excelService: GenericService,
               private filterService: FilterService ) {
               }

  exportAsXLSX(data):void {
    this.excelService.exportAsExcelFile(data, 'SiteTable');
  }

  public onLimitChange(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
    
    // this.changePageLimit(limit);
    // this.table.limit = this.currentPageLimit;
    // this.table.recalculate();
    // setTimeout(() => {
    //   if (this.table.bodyComponent.temp.length <= 0) {
        
    //     this.table.offset = Math.floor((this.table.rowCount - 1) / this.table.limit);

    //   }
    // });
  }

  private changePageLimit(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
  }

  ngOnInit() {
    
  }

  getIsShowColName({ row, column, value }) {   
    if(column.name =='name') {
     return {
       'hide': this.isShowColName
     };
    }
  }

  onDetailToggle(event) {
    //console.log('Detail Toggled', event);
  }

  getRowsHeight(childRows){
    return (childRows && childRows.length > 0) ? 20 : childRows.length * 20;
  }

  ignoreColumns=[
    'siteOldCustomerSiteId',
    'siteId'
  ];

  buildColumns(row){
    let keys = Object.keys(row);
    this.columns = keys.filter((key) => {
      return !Array.isArray(row[key]) && this.ignoreColumns.indexOf(key) == -1;
    });
  }

  ngOnChanges(simpleChanges: SimpleChanges){
    if(simpleChanges.tableRows.currentValue && simpleChanges.tableRows.currentValue.length){
       this.rawTableRows = simpleChanges.tableRows.currentValue;
      // this.buildColumns(simpleChanges.tableRows.currentValue[0]);
      this.redifinedColumns.sort((a, b) => {
        // if(!this.columnOrder[a] || !this.columnOrder[b]) return 0;
        let valuea = a.priority ? a.priority+'': 'z';
        let valueb = b.priority ? b.priority+'': 'z';
        return valuea.localeCompare(valueb);
      });
      this.selectedItems = this.allColumns = this.redifinedColumns;
    }
  }

  // onToggleHandler(event){
  //   this.onToggle.emit(event);
  // }

  rowClick(row) {
    
  }
  onSelect({selected}) {
    this.hideEventEmitter.emit(true);
    this.selectedRow.emit(selected[0]);
    
    var testing =[];
    for(var value in this.columnMap) {
      _.forEach(this.columns,function(items,key) {
      
          if(value === items) {
            testing.push(items);
          }
      });
      
  };
  this.columnsList.emit(testing);

    // _.forEach(this.columnMap,function(item) {
    //   // console.log('111', this.columnMap, '222', this.columns)
    //   // _.forEach(this.columns,function(items) {
    //   //   if(items===item) 
    //   //   this.testcase =item;
    //   //   console.log(this.testcase);
    //   // });
    //   console.log(item);
    // });
    
  }

  
  onItemSelect(item: any) {
    // console.log(item);
    this.redifinedColumns.unshift(item);
  }
  onDeSelect(item: any){
    // console.log(item);
    this.redifinedColumns = _.filter(this.redifinedColumns, col => {
      return col.id !== item.id;
    });
  }

  onFilterChange(colName, colValue){
    let filterProp = _.find(this.filterProps, prop=>{
      return colName == prop;
    });
    this.filterSearchKeys[colName] = colValue;
    if(!colValue){
      _.remove(this.filterProps, prop => {
        return prop == colName;
      });
      delete this.filterSearchKeys[colName];
    }else if(!filterProp){
      this.filterProps.push(colName);
    }
    this.tableRows = this.filterService.filterItems(this.rawTableRows, this.filterProps, this.filterSearchKeys)
  }

 /* onSort(event) {
    // event was triggered, start sort sequence
    console.log('Sort Event', event);
    this.loading = true;
    // emulate a server request with a timeout
    setTimeout(() => {
      const rows = [...this.tableRows];
      // this is only for demo purposes, normally
      // your server would return the result for
      // you and you would just set the rows prop
      const sort = event.sorts[0];
      rows.sort((a, b) => {
        return a[sort.prop].localeCompare(b[sort.prop]) * (sort.dir === 'desc' ? -1 : 1);
      });

      this.tableRows = rows;
      this.loading = false;
    }, 1000);
  }*/
}