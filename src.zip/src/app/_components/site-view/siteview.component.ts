import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { Subject } from 'rxjs';
import {AngularSplitModule} from 'angular-split';
import { HttpClientModule } from '@angular/common/http';
import { GenericService } from '../../_rest-service/generic.service';
import * as _ from 'lodash';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { SiteService } from './site-service/site.service';

@Component({
  selector: 'app-siteview',
  templateUrl: './siteview.component.html',
  styleUrls: ['./siteview.component.scss']
})
export class SiteviewComponent implements OnInit {
  
  selectedID: any;
  rows: any[] = [];
  columnHeaders;
  showTab = false;
  showCommonInfo = false;
  public 
  hideShow(event) { 
    // this.selectedSiteID = siteId;
    this.showCommonInfo = true;
    this.showTab = true;
  }

  selectedRowItem(event) {
    this.selectedID = event.siteCustomerSiteId;
    this.selectedRowItem = event;
  }

  columnsList(event) {
    this.columnHeaders = event;
  }

  constructor(private siteService : SiteService,
              private genericService : GenericService,
              private route: Router,
              private http: HttpClient ) { }

  exportAsXLSX(tableData):void {
    this.genericService.exportAsExcelFile(tableData, 'SiteView');
  }

  ngOnInit() {
    this.siteService.getSiteViewList().subscribe(data => {
      this.rows  = data;
  }); 
  }

  onDragEndHandler(event) {
    window.dispatchEvent(new Event('resize'));
  }
 
}
