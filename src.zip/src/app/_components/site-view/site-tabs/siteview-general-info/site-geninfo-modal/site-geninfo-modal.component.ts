import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SiteService } from '../../../site-service/site.service';

@Component({
  selector: 'app-site-geninfo-modal',
  templateUrl: './site-geninfo-modal.component.html',
  styleUrls: ['./site-geninfo-modal.component.scss']
})
export class SiteGeninfoModalComponent implements OnInit {

  closeBtnName: "Close";
  generalInfo : any[];
  flag= false;
  disableClose = false;
  states: { id: number; name: string; }[];
  generalInfoForm: FormGroup;
  countries;

 
  close() {
    this.bsModalRef.hide();
  }
  
  clear() {
    this.createForm();
  }

  test (){
    this.disableClose = true;
  }

  test2(){
    if(this.disableClose == true) {
      window.alert('test');
    }
    else {
      this.bsModalRef.hide();
    }
  }

  constructor(public bsModalRef: BsModalRef,
    private formBuilder: FormBuilder, 
    private siteService : SiteService) {
      this.createForm();
      this.getSiteGeneralInfo();
      this.getCountries();
      this.getStates();
    }

  getSiteGeneralInfo() {
    this.siteService.getSiteGeneralInfo().subscribe(value => {
      if(value)
      this.generalInfoForm.patchValue(value);
    });
  }

  getCountries() {
    this.countries = this.siteService.getCountriesList() ;
  }

  getStates () {
    this.states = this.siteService.getStatesList();
  }

  createForm() {
    this.generalInfoForm = this.formBuilder.group({
      customerSiteId: [''],
      name: [''],
      mainPhone :[''],
      npa:[''],
      pvp:[''],
      nxx:[''],
      streetAddress1:[''],
      districtDesc:[''],
      siteTypeDesc:[''],
      city:[''],
      zip:[''],
      regionDesc:[''],
      country:[''],
      espONum:[''],
      espAType:[''],
      stateDesc:[''],
      asbestosReportDesc:[''],
      blueprintDesc :[''],
  });
}
 
  ngOnInit() {
  }
}
