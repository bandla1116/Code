import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteGeninfoModalComponent } from './site-geninfo-modal.component';

describe('SiteGeninfoModalComponent', () => {
  let component: SiteGeninfoModalComponent;
  let fixture: ComponentFixture<SiteGeninfoModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteGeninfoModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteGeninfoModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
