import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { SiteGeninfoModalComponent } from './site-geninfo-modal/site-geninfo-modal.component';
import { SiteService } from '../../site-service/site.service';
@Component({
  selector: 'app-siteview-general-info',
  templateUrl: './siteview-general-info.component.html',
  styleUrls: ['./siteview-general-info.component.scss']
})
export class SiteviewGeneralInfoComponent implements OnInit {

  generalInfo: any;
  generalInfoForm: FormGroup;
  bsModalRef: BsModalRef;
  
  constructor(private siteService : SiteService, private modalService: BsModalService) { }

  getGeneralInfo() {
    this.siteService.getSiteGeneralInfo().subscribe(value => {
      if(value)
      this.generalInfo = value;
   });
  }

  openModalWithComponent(event) {
    event.stopPropagation();

    const initialState = {
      generalInfo : this.generalInfo,
    };
    this.bsModalRef = this.modalService.show(SiteGeninfoModalComponent, {
      initialState:initialState,
      backdrop : 'static',
      keyboard : false,
    });
    this.bsModalRef.content.closeBtnName = 'Close';
  }


  ngOnInit() {
    this.getGeneralInfo();
  }

}
