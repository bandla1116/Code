import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteviewDemarcComponent } from './siteview-demarc.component';

describe('SiteviewDemarcComponent', () => {
  let component: SiteviewDemarcComponent;
  let fixture: ComponentFixture<SiteviewDemarcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteviewDemarcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteviewDemarcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
