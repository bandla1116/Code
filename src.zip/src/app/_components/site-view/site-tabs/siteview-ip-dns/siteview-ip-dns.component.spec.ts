import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteviewIpDNSComponent } from './siteview-ip-dns.component';

describe('SiteviewIpDNSComponent', () => {
  let component: SiteviewIpDNSComponent;
  let fixture: ComponentFixture<SiteviewIpDNSComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteviewIpDNSComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteviewIpDNSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
