import { Component, OnInit } from '@angular/core';
import { SiteService } from '../../site-service/site.service';

@Component({
  selector: 'app-siteview-site-history',
  templateUrl: './siteview-site-history.component.html',
  styleUrls: ['./siteview-site-history.component.scss']
})
export class SiteviewSiteHistoryComponent implements OnInit {

  showDetails = false;
  siteHistoryTableData;
  siteHistoryListData;

  getRowDetails(data) {
    console.log(data.User); 
    //  This user ID might have to passed to the
    //   "getSiteHistoryListInfo" and then the 
    //    service might fetch table data
  }

  constructor(private siteSerivice : SiteService ) {
    this.siteHistoryTableData = this.siteSerivice.getSiteHistoryInfo();
    this.siteHistoryListData = this.siteSerivice.getSiteHistoryListInfo();
   }

  ngOnInit() {
  }

}
