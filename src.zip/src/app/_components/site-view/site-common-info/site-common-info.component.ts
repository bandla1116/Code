import { Component, OnInit ,Input } from '@angular/core';
import { GenericService } from '../../../_rest-service/generic.service';
import { SiteService } from '../site-service/site.service';

@Component({
  selector: 'app-site-common-info',
  templateUrl: './site-common-info.component.html',
  styleUrls: ['./site-common-info.component.scss']
})
export class SiteCommonInfoComponent implements OnInit {

  siteViewInfoList =[];

  constructor(public siteService : SiteService, private genericService: GenericService ) { 
    //this.siteCommonInfoData(this.genericService.selectedSiteId);
  }

  @Input() selectedRowItem: any;
  //This selectedSiteId will be used to fetch the service data later in the code.

  siteCommonInfoData(selectedRowItem) {
    this.siteService.getSiteCommonInfo(selectedRowItem).subscribe(data => {
      this.siteViewInfoList = data;
  });
  }
  ngOnInit() {
    this.siteCommonInfoData(this.selectedRowItem)
  }
}
