import { Component, OnInit, Input } from '@angular/core';
import { ConfirmationDialogService } from '../../../_rest-service/confirmation-dialog.service';
import { GenericService } from '../../../_rest-service/generic.service';

@Component({
  selector: 'app-siteview-sidebar',
  templateUrl: './siteview-sidebar.component.html',
  styleUrls: ['./siteview-sidebar.component.scss']
})
export class SiteviewSidebarComponent implements OnInit {

  isSidebarActive: boolean = true;

  @Input() selectedRow: any;
  @Input() columnHeaders: any;

  toggleSidebar(){
    this.isSidebarActive = !this.isSidebarActive;
  }

  constructor(private confirmationDialogService: ConfirmationDialogService, private genericService: GenericService) {}

  openConfirmationDialog() {
    this.genericService.selectedRow = this.selectedRow;
    this.confirmationDialogService.confirm('Add Sites','Would you like to add site based on the selected site ID?')
    .then((confirmed) => console.log('User confirmed:', confirmed))
    .catch(() => console.log('User dismissed the dialog (e.g., by using ESC, clicking the cross icon, or clicking outside the dialog)'));
  }

  ngOnInit() {
  }

}
