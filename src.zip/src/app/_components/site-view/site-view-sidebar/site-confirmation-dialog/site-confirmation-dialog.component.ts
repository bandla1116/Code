import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { GenericService } from '../../../../_rest-service/generic.service';

@Component({
  selector: 'app-site-confirmation-dialog',
  templateUrl: './site-confirmation-dialog.component.html',
  styleUrls: ['./site-confirmation-dialog.component.scss']
})
export class SiteConfirmationDialogComponent implements OnInit {

  addNewSiteDataFlag: boolean = false;
  @Input() title: string;
  @Input() message: string;
  @Input() btnOkText: string;
  @Input() btnCancelText: string;

  constructor(private activeModal: NgbActiveModal,
     private router: Router
    ) {
    
     }

  ngOnInit() {
  
  }

  public decline() {
    this.activeModal.close(false);
  }

  public accept() {
    this.addNewSiteDataFlag = true
    this.router.navigateByUrl('/siteAdd');
    this.activeModal.close(true);
  }

  public dismiss() {
    this.activeModal.dismiss();
  }

}
