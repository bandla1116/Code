import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteConfirmationDialogComponent } from './site-confirmation-dialog.component';

describe('SiteConfirmationDialogComponent', () => {
  let component: SiteConfirmationDialogComponent;
  let fixture: ComponentFixture<SiteConfirmationDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteConfirmationDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteConfirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
