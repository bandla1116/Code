import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-site-retrieve',
  templateUrl: './site-retrieve.component.html',
  styleUrls: ['./site-retrieve.component.scss']
})
export class SiteRetrieveComponent implements OnInit {

  constructor(private _location: Location) { }

  close() {
    this._location.back();
  }

  ngOnInit() {
  }

}
