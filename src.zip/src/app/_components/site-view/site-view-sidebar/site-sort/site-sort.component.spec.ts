import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteSortComponent } from './site-sort.component';

describe('SiteSortComponent', () => {
  let component: SiteSortComponent;
  let fixture: ComponentFixture<SiteSortComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteSortComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteSortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
