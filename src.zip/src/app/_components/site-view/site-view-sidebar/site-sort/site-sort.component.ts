import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-sort',
  templateUrl: './site-sort.component.html',
  styleUrls: ['./site-sort.component.scss']
})
export class SiteSortComponent implements OnInit {

  constructor() { }
  dropdownList;

  ngOnInit() {
  }

}
