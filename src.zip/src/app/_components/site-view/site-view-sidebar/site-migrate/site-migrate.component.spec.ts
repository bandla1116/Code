import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteMigrateComponent } from './site-migrate.component';

describe('SiteMigrateComponent', () => {
  let component: SiteMigrateComponent;
  let fixture: ComponentFixture<SiteMigrateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteMigrateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteMigrateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
