import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-site-migrate',
  templateUrl: './site-migrate.component.html',
  styleUrls: ['./site-migrate.component.scss']
})
export class SiteMigrateComponent implements OnInit {

  constructor(private _location: Location) {

   }

   close() {
    this._location.back();
  }
  ngOnInit() {
  }

}
