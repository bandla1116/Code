import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, ReactiveFormsModule  } from '@angular/forms'
import {Location} from '@angular/common';
import { SiteService } from '../../site-service/site.service';

@Component({
  selector: 'app-site-add-sites',
  templateUrl: './site-add-sites.component.html',
  styleUrls: ['./site-add-sites.component.scss']
})
export class SiteAddSitesComponent implements OnInit {

  states: { id: number; name: string; }[];
  addSiteForm: FormGroup;
  siteInformation : any;
  countries;

  constructor(private formBuilder: FormBuilder, 
              private _location: Location,
              private siteService : SiteService) {
      this.createForm();
      this.getSiteInfo();
      this.getCountries();
      this.getStates();
  }

  close() {
    this._location.back();
  }

  clear() {
    this.createForm();
  }

  getSiteInfo() {
    this.siteService.getSiteGeneralInfo().subscribe(value => {
      if(value)
      this.siteInformation = value;
      this.addSiteForm.patchValue(this.siteInformation);
   });
  }

  getCountries() {
    this.countries = this.siteService.getCountriesList() ;
  }

  getStates () {
    this.states = this.siteService.getStatesList();
  }

  createForm() {
    this.addSiteForm = this.formBuilder.group({
      customerSiteId: [''],
      name: [''],
      mainPhone :[''],
      npa:[''],
      pvp:[''],
      nxx:[''],
      streetAddress1:[''],
      districtDesc:[''],
      siteTypeDesc:[''],
      city:[''],
      zip:[''],
      regionDesc:[''],
      country:[''],
      espONum:[''],
      espAType:[''],
      stateDesc:[''],
      asbestosReportDesc:[''],
      blueprintDesc :[''],
  });
  }

  ngOnInit() {
   
      
  }

}
