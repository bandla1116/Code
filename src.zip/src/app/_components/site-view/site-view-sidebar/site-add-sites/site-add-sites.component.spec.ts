import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteAddSitesComponent } from './site-add-sites.component';

describe('SiteAddSitesComponent', () => {
  let component: SiteAddSitesComponent;
  let fixture: ComponentFixture<SiteAddSitesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteAddSitesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteAddSitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
