import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import * as _ from 'lodash';
import { ITreeOptions, ITreeState } from 'angular-tree-component';
import { treeData } from './work-flow.constants';
import { OrderService } from '../../order-view/order-service/order.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-work-flow',
  templateUrl: './work-flow.component.html',
  styleUrls: ['./work-flow.component.scss']
})
export class WorkFlowComponent implements OnInit {
  @Output() openWorkflowTabflag = new EventEmitter<number>();
  workflowTabOpenFlag: boolean = false;
  bsModalRef: BsModalRef;
  workflowData: any;
  state: ITreeState;
  constructor(private modalService: BsModalService, private orderService: OrderService, private route: Router) { }

  openModalWithComponent(event) {
    event.stopPropagation();
    const initialState = {
      list: [
        'Open a modal with component',
        'Pass your data',
        'Do something else',
        '...'
      ],
      title: 'Modal with component'
    };
    this.bsModalRef = this.modalService.show(ModalContentComponent, {
      initialState: initialState,
      backdrop: 'static'
    });
    this.bsModalRef.content.closeBtnName = 'Close';
  }

  nodes = [];

  navigateToWFTab(id) {
    this.openWorkflowTabflag.emit(6);
  }
  

  options: ITreeOptions = {
    idField: 'TASKJOBID',
    displayField: 'NAME',
    childrenField: 'children'
  };

  nodeClickAction(node:any){
    this.navigateToWFTab(node);
  }

  createTreeNode(treeArray){
    for(let i = treeArray.length; i > 0; i--){
      _.forEach(treeArray[i], node => {
        let foundItem = _.find(treeArray[i - 1], item => {
          return item.taskJobId == node.parentTaskId;
        });
        if(foundItem){
          foundItem.children = foundItem.children || [];
          foundItem.children.push(node);
        }
      });
    };
    return treeArray[1];
  }

  transformResponseToTreeFormat(response:any[]){
    let responseLength = response.length;
    let treeLength = 0;
    let treeArray = [];
    let i = 0;
    do {
      treeArray[i] = _.filter(response, res => {
        return res.level == i;
      });
      treeLength = treeLength + treeArray[i].length;
      i++;
    }
    while (treeLength < responseLength);
    return this.createTreeNode(treeArray);
  }



  ngOnInit() {
    // this.orderService.getOrderWorkflowData().subscribe(response => {
    //   this.workflowData = response;
    // })
    this.nodes = this.transformResponseToTreeFormat(treeData);
  }

}

@Component({
  selector: 'modal-content',
  template: `
  
    <div class="modal-header" >
      <h4 class="modal-title pull-left">{{title}}</h4>
      <button type="button" class="close pull-right" aria-label="Close" (click)="bsModalRef.hide()">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <ul *ngIf="list.length">
        <li *ngFor="let item of list">{{item}}</li>
      </ul>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-default" (click)="bsModalRef.hide()">{{closeBtnName}}</button>
    </div>

  `
})
 
export class ModalContentComponent implements OnInit {
  title: string;
  closeBtnName: string;
  list: any[] = [];
 
  constructor(public bsModalRef: BsModalRef) {}
 
  ngOnInit() {
    this.list.push('Workflow modal');
  }
}
