import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workflowtab',
  templateUrl: './workflowtab.component.html',
  styleUrls: ['./workflowtab.component.scss']
})
export class WorkflowtabComponent implements OnInit {

  completeIndicator: string = 'Complete';
  requiredIndicator = "Required"
  completeind: boolean = false;
  constructor() { }

  workflowCompleteInfo() {
    if(this.completeind === false) {
      this.completeIndicator = 'Not Complete';
      this.completeind = true;
    } else {
      this.completeIndicator = 'Complete';
      this.completeind = false;
    }
    
  }

  workflowReqInfo() {
    if(this.completeind === false) {
      this.requiredIndicator = 'Not Required';
      this.completeind = true;
    } else {
      this.requiredIndicator = 'Required';
      this.completeind = false;
    }
  }

  workflowJeopardy() {

  }

  workflowHold() {

  }

  workflowAddNote () {

  }

  ngOnInit() {
  }
}
