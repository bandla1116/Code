import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sites',
  templateUrl: './sites.component.html',
  styleUrls: ['./sites.component.scss']
})
export class SitesComponent implements OnInit {

  constructor() { }

  rows = [];
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  columns = [
    { name: 'USPS Site ID', summaryFunc: () => null },
    { name: 'Migrated', summaryFunc: () => null },
    { name: 'Site Type', summaryFunc: () => null },
    { name: 'FDB ID', summaryFunc: () => null },
    { name: 'Facility Name', summaryFunc: () => null },
    { name: 'City', summaryFunc: () => null },
    { name: 'State', summaryFunc: () => null },
    { name: 'Zipcode', summaryFunc: () => null },
    { name: 'District', summaryFunc: () => null },
    { name: 'PVP', summaryFunc: () => null },
  ];
  con

  ngOnInit() {
  }

}
