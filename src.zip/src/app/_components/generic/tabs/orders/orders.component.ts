import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {
  rows = [];
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  columns = [
    { name: 'Customer Order #', summaryFunc: () => null },
    { name: 'Customer Order Category', summaryFunc: () => null },
    { name: 'Customer Action Type', summaryFunc: () => null },
    { name: 'Order Status', summaryFunc: () => null },
    { name: 'FROM', summaryFunc: () => null },
    { name: 'Facility Name', summaryFunc: () => null },
    { name: 'FROM State', summaryFunc: () => null },
    { name: 'FROM USPS Site ID', summaryFunc: () => null },
    { name: 'TO Facility Name', summaryFunc: () => null },
    { name: 'TO State', summaryFunc: () => null },
    { name: 'TO USPS Site ID', summaryFunc: () => null },
    { name: 'Order Received Date', summaryFunc: () => null },
    { name: 'USPS Req Due Date', summaryFunc: () => null },
    { name: 'SDP Type', summaryFunc: () => null },
    { name: 'Current Date Rate', summaryFunc: () => null },
    { name: 'Previous Date Rate', summaryFunc: () => null }
  ];

  constructor() { }

  ngOnInit() {
  }

}
