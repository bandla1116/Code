import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-view-general-info',
  templateUrl: './service-view-general-info.component.html',
  styleUrls: ['./service-view-general-info.component.scss']
})
export class ServiceViewGeneralInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
