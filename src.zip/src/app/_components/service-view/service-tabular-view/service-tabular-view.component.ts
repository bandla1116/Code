import { Component, OnInit, ViewChild, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { GenericService } from '../../../_rest-service/generic.service';
import { FilterService } from '../../../_rest-service/filter.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-service-tabular-view',
  templateUrl: './service-tabular-view.component.html',
  styleUrls: ['./service-tabular-view.component.scss']
})
export class ServiceTabularViewComponent implements OnInit {
  @ViewChild('myTable') table: any;
  @Input() tableRows:any;
  @Output() hideEventEmitter = new EventEmitter<boolean>();
  @Output() selectedRow = new EventEmitter<any>();
  @Output() columnsList = new EventEmitter<any>();
  loadingIndicator: boolean = true;
  reorderable: boolean = true;
  isShowColName: boolean = false;
  columnHeaders={};
  loading: boolean = false;
  constructor(private excelService: GenericService,
    private filterService: FilterService) { }

  columnMap: any = {
    'migrated' : "Migrated Id",
    'class':"Class",
      "subClass": "Sub Class",
      "status": "Status",
      "Identifier": "Identifier",
      "customerOrderNumber": "Customer Order Number",
      "SDPType": "SDP Type",
      "currentDataRate": "Current Data Rate",
      "VxBAcceptanceRate": "Vx BAcceptance Rate",
      "InstallDate": "Install Date",
      "ActiveDate": "Active Date",
      "DisconnectDate": "Disconnect Date"
  };
  private rawTableRows:any[] = [];
  private filterProps:any[] = [];
  private filterSearchKeys:any = {};
  columns : any[];
  allColumns: any[];
  selectedItems = [];
  selected = [];
  dropdownSettings = {
    singleSelection: false,
    itemsShowLimit: 3,
    allowSearchFilter: false,
    enableCheckAll: false,
    idField: 'id',
    textField: 'name'
  };

  public currentPageLimit: number = 10;
  public currentVisible: number = 3;
  public readonly pageLimitOptions = [
    {value: 5},
    {value: 10},
    {value: 25},
    {value: 50},
    {value: 100},
  ];
  redifinedColumns = 
  [
    {
      id : 'migrated',
      name : 'Migrated Id',
      priority : 1
    },
    {
      id : 'class',
      name : 'Class',
      priority : 2
    },
    {
      id : 'subClass',
      name : 'Sub Class',
      priority : 3
    },
    {
      id : 'status',
      name : 'Status',
      priority : 4
    },
    {
      id : 'Identifier',
      name : 'Identifier',
      priority : 5
    },
    {
      id : 'customerOrderNumber',
      name : 'Customer Order Number',
      priority : 6
    },
    {
      id : 'SDPType',
      name : 'SDP Type',
      priority : 7
    },
    {
      id : 'currentDataRate',
      name : 'Current Data Rate',
      priority : 8
    },
    {
      id : 'VxBAcceptanceRate',
      name : 'VxB Acceptance Rate',
      priority : 9
    },
    {
      id : 'InstallDate',
      name : 'Install Date',
      priority : 10
    },
    {
      id : 'ActiveDate',
      name : 'Active Date',
      priority : 11
    },
    {
      id : 'DisconnectDate',
      name : 'Disconnect Date',
      priority : 12
    }
  ]

  exportAsXLSX(data):void {
    this.excelService.exportAsExcelFile(data, 'SiteTable');
  }

  public onLimitChange(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
  }

  private changePageLimit(limit: any): void {
    this.currentPageLimit = parseInt(limit, 10);
  }

  getIsShowColName({ row, column, value }) {   
    if(column.name =='name') {
     return {
       'hide': this.isShowColName
     };
    }
  }
  getRowsHeight(childRows){
    return (childRows && childRows.length > 0) ? 20 : childRows.length * 20;
  }
  ignoreColumns=[
    'siteOldCustomerSiteId',
    'siteId'
  ];
  buildColumns(row){
    let keys = Object.keys(row);
    this.columns = keys.filter((key) => {
      return !Array.isArray(row[key]) && this.ignoreColumns.indexOf(key) == -1;
    });
  }
  ngOnChanges(simpleChanges: SimpleChanges){
    if(simpleChanges.tableRows.currentValue && simpleChanges.tableRows.currentValue.length){
       this.rawTableRows = simpleChanges.tableRows.currentValue;
      this.redifinedColumns.sort((a, b) => {
        let valuea = a.priority ? a.priority+'': 'z';
        let valueb = b.priority ? b.priority+'': 'z';
        return valuea.localeCompare(valueb);
      });
      this.selectedItems = this.allColumns = this.redifinedColumns;
    }
  }
  onSelect({selected}) {
    this.hideEventEmitter.emit(true);
    this.selectedRow.emit(selected[0]);
    var testing =[];
    for(var value in this.columnMap) {
      _.forEach(this.columns,function(items,key) {
      
          if(value === items) {
            testing.push(items);
          }
      });
      
  };
  this.columnsList.emit(testing);
  }
  onItemSelect(item: any) {
    this.redifinedColumns.unshift(item);
  }
  onDeSelect(item: any){
    this.redifinedColumns = _.filter(this.redifinedColumns, col => {
      return col.id !== item.id;
    });
  }
  onFilterChange(colName, colValue){
    let filterProp = _.find(this.filterProps, prop=>{
      return colName == prop;
    });
    this.filterSearchKeys[colName] = colValue;
    if(!colValue){
      _.remove(this.filterProps, prop => {
        return prop == colName;
      });
      delete this.filterSearchKeys[colName];
    }else if(!filterProp){
      this.filterProps.push(colName);
    }
    this.tableRows = this.filterService.filterItems(this.rawTableRows, this.filterProps, this.filterSearchKeys)
  }
  ngOnInit() {
  }

}
