import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceTabularViewComponent } from './service-tabular-view.component';

describe('ServiceTabularViewComponent', () => {
  let component: ServiceTabularViewComponent;
  let fixture: ComponentFixture<ServiceTabularViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceTabularViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceTabularViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
