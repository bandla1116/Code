import { TestBed } from '@angular/core/testing';

import { ServiceViewService } from './service-view.service';

describe('ServiceViewService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServiceViewService = TestBed.get(ServiceViewService);
    expect(service).toBeTruthy();
  });
});
