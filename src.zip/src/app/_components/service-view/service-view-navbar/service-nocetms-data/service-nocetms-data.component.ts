import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import {Location} from '@angular/common';

@Component({
  selector: 'app-service-nocetms-data',
  templateUrl: './service-nocetms-data.component.html',
  styleUrls: ['./service-nocetms-data.component.scss']
})
export class ServiceNocetmsDataComponent implements OnInit {

  etmsForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
              private _location: Location) {
    this.createForm();
  }

  close() {
    this._location.back();
  }

  createForm() {
    this.etmsForm = this.formBuilder.group({
      customerSiteId: [''],
      name: [''],
      mainPhone :[''],
      npa:[''],
      pvp:[''],
      nxx:[''],
      streetAddress1:[''],
      districtDesc:[''],
      siteTypeDesc:[''],
      city:[''],
      zip:[''],
      regionDesc:[''],
      country:[''],
      espONum:[''],
      espAType:[''],
      stateDesc:[''],
      asbestosReportDesc:[''],
      blueprintDesc :[''],
  });
  }

  ngOnInit() {
  }

}
