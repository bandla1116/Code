import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceNocetmsDataComponent } from './service-nocetms-data.component';

describe('ServiceNocetmsDataComponent', () => {
  let component: ServiceNocetmsDataComponent;
  let fixture: ComponentFixture<ServiceNocetmsDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceNocetmsDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceNocetmsDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
