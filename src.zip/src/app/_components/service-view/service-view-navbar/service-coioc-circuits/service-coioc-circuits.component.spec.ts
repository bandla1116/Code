import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceCoiocCircuitsComponent } from './service-coioc-circuits.component';

describe('ServiceCoiocCircuitsComponent', () => {
  let component: ServiceCoiocCircuitsComponent;
  let fixture: ComponentFixture<ServiceCoiocCircuitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceCoiocCircuitsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceCoiocCircuitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
