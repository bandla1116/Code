import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-service-coioc-circuits',
  templateUrl: './service-coioc-circuits.component.html',
  styleUrls: ['./service-coioc-circuits.component.scss']
})
export class ServiceCoiocCircuitsComponent implements OnInit {

  constructor(private _location: Location) { }


  close() {
    this._location.back();
  }

  ngOnInit() {
  }

}
