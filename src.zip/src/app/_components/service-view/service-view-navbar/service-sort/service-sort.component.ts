import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-service-sort',
  templateUrl: './service-sort.component.html',
  styleUrls: ['./service-sort.component.scss']
})
export class ServiceSortComponent implements OnInit {

  constructor(private _location: Location) { }

  close() {
    this._location.back();
  }

  ngOnInit() {
  }

}
