import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceSortComponent } from './service-sort.component';

describe('ServiceSortComponent', () => {
  let component: ServiceSortComponent;
  let fixture: ComponentFixture<ServiceSortComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceSortComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceSortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
