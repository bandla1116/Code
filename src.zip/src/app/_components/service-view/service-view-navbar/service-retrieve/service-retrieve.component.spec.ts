import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceRetrieveComponent } from './service-retrieve.component';

describe('ServiceRetrieveComponent', () => {
  let component: ServiceRetrieveComponent;
  let fixture: ComponentFixture<ServiceRetrieveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceRetrieveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceRetrieveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
