import { Component, OnInit, ViewChild } from '@angular/core';
import {Location} from '@angular/common';
import { DaterangePickerComponent } from 'ng2-daterangepicker';

@Component({
  selector: 'app-service-retrieve',
  templateUrl: './service-retrieve.component.html',
  styleUrls: ['./service-retrieve.component.scss']
})
export class ServiceRetrieveComponent implements OnInit {

  constructor(private _location: Location) { }

  public daterange: any = {
    start: Date.now(),
    end: Date.now(),
    label: ''
  };

  @ViewChild(DaterangePickerComponent)
  private picker: DaterangePickerComponent;

  public options: any = {
    locale: { format: 'YYYY-MM-DD' },
    alwaysShowCalendars: false,
  }

  public selectedDate(value: any) {
    console.log('1111', value);
    this.daterange.start = value.start;
    this.daterange.end = value.end;
  }

  public applyDate(e: any) {
    console.log(e)
    //this.daterange.start = e.picker.startDate;
    //this.daterange.end = e.picker.endDate;
  }

  // ngAfterViewInit() {
  //   this.picker.datePicker.setStartDate('2007-03-27');
  // }

  close() {
    this._location.back();
  }


  ngOnInit() {
  }

}
