import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-view-navbar',
  templateUrl: './service-view-navbar.component.html',
  styleUrls: ['./service-view-navbar.component.scss']
})
export class ServiceViewNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
