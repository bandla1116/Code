import { Component, OnInit } from '@angular/core';
import { GenericService } from '../../_rest-service/generic.service';
import { ServiceViewService } from '../../_rest-service/service-view.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-service-view',
  templateUrl: './service-view.component.html',
  styleUrls: ['./service-view.component.scss']
})
export class ServiceViewComponent implements OnInit {
  columnHeaders;
  serviceviewTableData;
  selectedServiceID;
  hideShowFlag: boolean = false;
  hideShowTabFlag: boolean = false;
  generalInfoFlag: boolean= false;
  rows: any[] = [];

  constructor(private serviceviewService : ServiceViewService, 
              private excelService: GenericService,
              private route: Router,
              private http: HttpClient) { }

  exportAsXLSX(tableData):void {
    this.excelService.exportAsExcelFile(tableData, 'serviceview');
  }

  hideShow(event) { 
    // this.selectedSiteID = siteId;
    this.hideShowFlag = true;
    this.hideShowTabFlag = true;
  }

  getServiceRowData(serviceID) {
    this.selectedServiceID = serviceID;
    this.hideShowTabFlag = true;
  }

  columnsList(event) {
    this.columnHeaders = event;
  }

  ngOnInit() {
    this.serviceviewService.getSeriviceviewTableData().subscribe(data => {
      this.rows  = data;
  });  
  }

  onDragEndHandler(event) {
    window.dispatchEvent(new Event('resize'));
  }

}
