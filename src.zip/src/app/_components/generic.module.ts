import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ExportAsModule } from 'ngx-export-as';
import { AngularSplitModule } from 'angular-split';
import { TabsModule, BsModalService } from 'ngx-bootstrap';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TreeModule } from 'angular-tree-component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TreeviewModule } from 'ngx-treeview';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { Daterangepicker } from 'ng2-daterangepicker';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { ServiceViewGeneralInfoComponent } from './service-view/service-view-tab/service-view-general-info/service-view-general-info.component';
import { ServiceViewComponent } from './service-view/service-view.component';
import { OrderProposalsComponent } from './order-view/order-tab/order-view-proposals/order-proposals.component';
import { OrderHistoryComponent } from './generic/tabs/order-history/order-history.component';
import { SitesComponent } from './generic/tabs/sites/sites.component';
import { SiteRetrieveComponent } from './site-view/site-view-sidebar/site-retrieve/site-retrieve.component';
import { OrderRetrieveComponent } from './order-view/order-view-sidebar/order-retrieve/order-retrieve.component';
import { WorkflowtabComponent } from './generic/tabs/work-flow-tab/workflowtab.component';
import { OrderviewClinsComponent } from './order-view/order-tab/order-view-clins/orderview-clins.component';
import { OrderviewContactsComponent } from './order-view/order-tab/order-view-contacts/orderview-contacts.component';
import { OrderviewGeneralInfoComponent } from './order-view/order-tab/order-view-general-info/orderview-general-info.component';
import { OrderNewModalComponent} from './order-view/order-view-sidebar/order-new-modal/order-new-modal.component';
import { SupplementModificationModalComponent} from './order-view/order-view-sidebar/supplement-modification-modal/supplement-modification-modal.component';
import { OrderCancelModalComponent} from './order-view/order-view-sidebar/order-cancel-modal/order-cancel-modal.component';
import { SiteCommonInfoComponent } from './site-view/site-common-info/site-common-info.component';
import { SiteviewContactsComponent } from './site-view/site-tabs/siteview-contacts/siteview-contacts.component';
import { SiteviewIpDNSComponent } from './site-view/site-tabs/siteview-ip-dns/siteview-ip-dns.component';
import { OrderViewComponent } from './order-view/orderview.component';
import { OrderviewSidebarComponent } from './order-view/order-view-sidebar/order-view-sidebar.component';
import { ModalContentComponent, WorkFlowComponent } from './generic/work-flow/work-flow.component';
import { SiteviewComponent } from './site-view/siteview.component';
import { SiteviewSiteHistoryComponent } from './site-view/site-tabs/siteview-site-history/siteview-site-history.component';
import { SiteviewSidebarComponent } from './site-view/site-view-sidebar/siteview-sidebar.component';
import { CommentsComponent } from './generic/tabs/comments/comments.component';
import { OrdersComponent } from './generic/tabs/orders/orders.component';
import { OrdersItemsComponent } from './generic/tabs/orders-items/orders-items.component';
import { ServicesComponent } from './generic/tabs/services/services.component';
import { SiteviewGeneralInfoComponent } from './site-view/site-tabs/siteview-general-info/siteview-general-info.component';
import { SiteviewDemarcComponent } from './site-view/site-tabs/siteview-demarc/siteview-demarc.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { OrderTabularViewComponent } from './order-view/order-tabular-view/order-tabular-view.component';
import { SiteTabularViewComponent } from './site-view/site-tabular-view/site-tabular-view/site-tabular-view.component';
import { OrderNewComponent } from './order-view/order-view-sidebar/order-new/order-new.component';
import { SiteGeninfoModalComponent } from './site-view/site-tabs/siteview-general-info/site-geninfo-modal/site-geninfo-modal.component';
import { SiteMigrateComponent } from './site-view/site-view-sidebar/site-migrate/site-migrate.component';
import { SiteConfirmationDialogComponent } from './site-view/site-view-sidebar/site-confirmation-dialog/site-confirmation-dialog.component';
import { SiteAddSitesComponent } from './site-view/site-view-sidebar/site-add-sites/site-add-sites.component';
import { ConfirmationDialogService } from '../_rest-service/confirmation-dialog.service';
import { OrderItemViewComponent } from './order-item-view/order-item-view.component';
import { OrderItemTabularViewComponent } from './order-item-view/order-item-tabular-view/order-item-tabular-view.component';
import { OrderItemViewSidebarComponent } from './order-item-view/order-item-view-sidebar/order-item-view-sidebar.component';
import { SiteSortComponent } from './site-view/site-view-sidebar/site-sort/site-sort.component';
import { FindComponent } from './find/find.component';
import { ServiceTabularViewComponent } from './service-view/service-tabular-view/service-tabular-view.component';
import { ServiceViewNavbarComponent } from './service-view/service-view-navbar/service-view-navbar.component';
import { ServiceSortComponent } from './service-view/service-view-navbar/service-sort/service-sort.component';
import { ServiceCoiocCircuitsComponent } from './service-view/service-view-navbar/service-coioc-circuits/service-coioc-circuits.component';
import { ServiceRetrieveComponent } from './service-view/service-view-navbar/service-retrieve/service-retrieve.component';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    HttpClientModule,
    NgxDatatableModule,
    ExportAsModule,
    AngularSplitModule,
    NgxPaginationModule,    
    ReactiveFormsModule, 
    PerfectScrollbarModule,
    TabsModule.forRoot(),
    TreeModule.forRoot(),
    ModalModule.forRoot(),
    TreeviewModule.forRoot(),
    BsDatepickerModule.forRoot(),
    Daterangepicker,
    NgMultiSelectDropDownModule.forRoot(),
  ],
  entryComponents: [
    ModalContentComponent,
    OrderNewModalComponent,
    SupplementModificationModalComponent,
    OrderCancelModalComponent,
    SiteGeninfoModalComponent,
    SiteConfirmationDialogComponent
  ],
  declarations: [
    SiteviewComponent,
    SiteviewSiteHistoryComponent,
    SiteviewSidebarComponent,
    CommentsComponent,
    OrdersComponent,
    OrdersItemsComponent,
    ServicesComponent,
    SiteviewGeneralInfoComponent,
    SiteviewDemarcComponent,
    OrderViewComponent,
    WorkFlowComponent,
    OrderviewSidebarComponent,
    ModalContentComponent,
    SiteviewIpDNSComponent,
    SiteviewContactsComponent,
    SiteCommonInfoComponent,
    OrderviewGeneralInfoComponent,
    OrderviewContactsComponent,
    OrderviewClinsComponent,
    OrderNewModalComponent,
    SupplementModificationModalComponent,
    OrderCancelModalComponent,
    WorkflowtabComponent,
    OrderRetrieveComponent,
    SiteRetrieveComponent,
    SitesComponent,
    OrderHistoryComponent,
    OrderProposalsComponent,
    ServiceViewComponent,
    OrderTabularViewComponent,
    ServiceViewGeneralInfoComponent,
    SiteTabularViewComponent,
    OrderNewComponent,
    SiteGeninfoModalComponent,
    SiteMigrateComponent,
    SiteAddSitesComponent,
    OrderItemViewComponent,
    OrderItemTabularViewComponent,
    OrderItemViewSidebarComponent,
    SiteSortComponent,
    FindComponent,
    ServiceTabularViewComponent,
    ServiceViewNavbarComponent,
    ServiceSortComponent,
    ServiceCoiocCircuitsComponent,
    ServiceRetrieveComponent
  ],
  providers: [
    HttpClient, ConfirmationDialogService,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class GenericModule { }
