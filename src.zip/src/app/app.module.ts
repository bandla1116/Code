import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './_core/app.routing.module';
import { HttpClient } from '@angular/common/http';
import { GenericModule } from './_components/generic.module';
import { NewOrderComponent } from './_components/order-view/order-view-sidebar/new-order/new-order.component';
import { LoginModule } from './_login/login.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ApplicationPageComponent } from './application-page/application-page.component';
import { DashboardModule } from './_dashboard/dashboard.module';
import { RouterModule } from '@angular/router';
import { SiteAddSitesComponent } from './_components/site-view/site-view-sidebar/site-add-sites/site-add-sites.component';
import { SiteConfirmationDialogComponent } from './_components/site-view/site-view-sidebar/site-confirmation-dialog/site-confirmation-dialog.component';
import { MyProfileComponent } from './_dashboard/my-profile/my-profile.component';
import { TabsModule } from 'ngx-bootstrap';
import { ServiceNocetmsDataComponent } from './_components/service-view/service-view-navbar/service-nocetms-data/service-nocetms-data.component';

@NgModule({
  declarations: [
    AppComponent,
    NewOrderComponent,
    ApplicationPageComponent,
    SiteConfirmationDialogComponent,
    MyProfileComponent,
    ServiceNocetmsDataComponent,
       
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    GenericModule,
    DashboardModule,
    LoginModule,
    RouterModule,
    TabsModule,
    BrowserAnimationsModule,
    NgbModule.forRoot()
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
