import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, ReactiveFormsModule  } from '@angular/forms'
import {Location} from '@angular/common';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {

  profileForm: FormGroup;

  constructor(private formBuilder: FormBuilder, 
    private _location: Location) { 
    this.createForm();
  }

  close() {
    this._location.back();
  }

  createForm() {
    this.profileForm = this.formBuilder.group({
      title:[''],
      address:[''],
      phone:[''],
      vnetNumber:[''],
      fax:[''],
      pager:[''],
      email:[''],
      city:[''],
      state:[''],
      zipcode:[''],
      country:['']
    });
  }

  ngOnInit() {
  }

}
