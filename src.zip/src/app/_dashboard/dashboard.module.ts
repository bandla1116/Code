import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { RouterModule } from '@angular/router';
import { TabsModule } from 'ngx-bootstrap';
import { AdministrationComponent } from './administration/administration.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    TabsModule,
    NgbModule
  ],
  declarations: [
    DashboardComponent,
    AdministrationComponent
  ]
})
export class DashboardModule { }
