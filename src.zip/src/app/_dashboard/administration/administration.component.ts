import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administration',
  templateUrl: './administration.component.html',
  styleUrls: ['./administration.component.scss']
})
export class AdministrationComponent implements OnInit {

  selectTab: string;
  showDetails = false;
  constructor() { }

  ngOnInit() {
  }

  selectCodeTables(type: string = 'home'): void {
    this.selectTab = 'home';
  }
}
