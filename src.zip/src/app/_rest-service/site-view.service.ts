import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SiteViewService {

  constructor(private http : HttpClient) { }

  getSiteViewList(): Observable<any> {
    return this.http.get("./assets/siteTable.json");
  };

  getSiteCommonInfo(siteId): Observable<any> {
    if(siteId == '102203-8101') {
      return this.http.get("./assets/siteCommoninfo.json");
    } else if (siteId == '104006-4151') {
      return this.http.get("./assets/siteCommoninfo1.json");
    }
    else {
      return this.http.get("./assets/siteCommoninfo.json");
    }
  };

  /* Fetches SiteView->SiteGeneralInformation Data */

  getSiteGeneralInfo(): Observable<any> {
    return this.http.get("./assets/siteGeneralinfo.json");
  };
  

  // getSiteGeneralInfo() {
  //   const siteGeneralInfo = [
  //     {
  //       siteId: 1052,
  //       customerSiteId: 105000 - 8249,
  //       name: "NAVY ANNEX STA",
  //       streetAddress1: "1 NAVY ANNEX BLDG FOB2",
  //       city: "ARLINGTON",
  //       stateDesc: "Virginia",
  //       zip: "22214-0001",
  //       country: 'Canada',
  //       regionDesc: "Mid-Atlantic- Southeast",
  //       districtDesc: "CAPITAL",
  //       pvp: "PYM ",
  //       npa: 703,
  //       nxx: 695,
  //       asbestosReportDesc: "Yes",
  //       blueprintDesc: '',
  //       siteTypeDesc: "01 - SMALL ASSOCIATE OFFICE",
  //       mainPhone: 703 - 271 - 9185,
  //       fdbId: null,

  //     }]
  //   return siteGeneralInfo;
  // }

  getCountriesList() {
    const countriesList = [{
      id: 0,
      name: "USA"
    },
    {
      id: 1,
      name: "Canada"
    }
    ]
    return countriesList;
  }

  getStatesList() {
    const statesList = [{
      id: 0,
      name: "Alaska"
    },
    {
      id: 1,
      name: "Virginia"
    }
    ]
    return statesList;
  }

  getDistrictsList() {
    const districtsList = [{
      id: 0,
      name: "Alabama"
    },
    {
      id: 1,
      name: "Alaska"
    },
    {
      id: 1,
      name: "Albani"
    },
    {
      id: 1,
      name: "Atlanta"
    },
    {
      id: 1,
      name: "Baltimore"
    },
    {
      id: 1,
      name: "Chicago"
    },
    {
      id: 1,
      name: "Dallas"
    }
    ]
    return districtsList;
  }

  /* Fetches SiteView->Sitecontacts Table Information */

  getSiteContactsInfo() {
    const siteContactsInfo = {
      "secondaryContact": {
        "firstName": "Awadhesh1",
        "middleName": "Kumar1",
        "lastName": "Katiyar1",
        "phonenumber": "9999999991"
      },
      "AOICoordinator": {
        "firstName": "Awadhesh2",
        "middleName": "Kumar2",
        "lastName": "Katiyar2",
        "phonenumber": "9999999992"
      },
      "MIS": {
        "firstName": "Awadhesh3",
        "middleName": "Kumar3",
        "lastName": "Katiyar3",
        "phonenumber": "9999999993"
      },
      // "primaryContact": {
      //     "firstName": "Awadhesh",
      //     "middleName": "Kumar",
      //     "lastName": "Katiyar",
      //     "phonenumber": "9999999990"
      // }
    }

    return siteContactsInfo;
  }

  /* Fetches SiteView->SiteHistory Table Information */

  // getSiteHistoryInfo(): Observable<any> {
  //   return this.http.get("./assets/siteCommoninfo.json");
  // };

  getSiteHistoryInfo() {
    const siteHistoryInfo = [{
      Subject: "Site Data Modified",
      User: "Tara",
      Data: "02/14/2016"
    }]
    return siteHistoryInfo;
  }

  /* Fetches SiteView->SiteHistory List Information */

  getSiteHistoryListInfo() {
    const siteHistoryListInfo = [{
      DateTime: "02/12/2012 9:14",
      SiteHistory: "Site Main Site Phone Number changed from {Blank} to 907-789-0934",
    }]
    return siteHistoryListInfo;
  }

  /* Fetches SiteView->Demarc Table Information */

  getSiteDemarcInfo() {
    const siteDemarcInfo = {
      demarc: {
        "buildingName": "A1",
        "floorName": "F1",
        "roomName": "K1",
        "note": "First"
      },
      // extend: {
      //   "buildingName": "A2",
      //   "floorName": "F2",
      //   "roomName": "K2",
      //   "note": "Second"
      // }
    }
    return siteDemarcInfo;
  }
  /* Fetches SiteView->Orders Table Information */

  getSiteOrdersTableData() {
    const siteOrdersTableData = [{

    }]
    return siteOrdersTableData;
  }

  /* Fetches SiteView->Orders Items Table Information */

  getSiteOrdersItemsTableData() {
    const siteOrdersItemsTableData = [{

    }]
    return siteOrdersItemsTableData;
  }

  /* Fetches SiteView->Services Table Information */

  getSiteServicesTableData() {
    const siteServicesTableData = [{

    }]
    return siteServicesTableData;
  }
}
