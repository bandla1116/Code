import { Injectable } from '@angular/core';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class FilterService {

  constructor() { }
  
  filterItems(totalItems:any[], props:any[],searchKeys:any){
    if(props.length <= 0) return totalItems;
    let filteredArray = [];
    _.each(totalItems, item =>{
      let match = true;
      _.each(props, prop => {
        let comparableItem = _.get(item, prop);
        comparableItem = comparableItem ? (comparableItem+'').toLowerCase().trim() : '';
        let searchTerm = searchKeys[prop] ? (searchKeys[prop]+'').toLowerCase().trim() : '';
        if(searchTerm && comparableItem && comparableItem.indexOf(searchTerm) > -1 && match){
          match = true;
        }else{
          match = false;
        }
      });
      if(match){
        filteredArray.push(item);
      }
    });
    return filteredArray;
  }
}
