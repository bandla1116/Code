import { TestBed } from '@angular/core/testing';
import { OrderViewService } from './order-view.service';

describe('OrderViewService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OrderViewService = TestBed.get(OrderViewService);
    expect(service).toBeTruthy();
  });
});
