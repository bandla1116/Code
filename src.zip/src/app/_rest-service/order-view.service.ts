import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderViewService {
  //private baseUrl = 'http://localhost:8080/orders/1/1/1/1/1/1/1/1';
  constructor(private http: HttpClient) { }
  // getOrdersList(): Observable<any> {
  //   console.log("vvvvvvva");
  //   return this.http.get(this.baseUrl);
  // }

  getOrderViewTable(): Observable<any> {
    return this.http.get("./assets/orderviewTable.json");
  };

  getOrderWorkflowData(): Observable<any> {
    return this.http.get("./assets/orderViewWorkflowData.json");
  }

  getOrderGeneralInfo(): Observable<any> {
    return this.http.get("./assets/orderviewGeneralinfo.json");
  }

  getClinsInfo(): Observable<any> {
    return this.http.get("./assets/orderviewClinsinfo.json");
  }
}
