import {NgModule}  from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderViewComponent } from '../_components/order-view/orderview.component';
import { ServiceViewComponent } from '../_components/service-view/service-view.component';
import { SiteRetrieveComponent } from '../_components/site-view/site-view-sidebar/site-retrieve/site-retrieve.component';
import { OrderRetrieveComponent } from '../_components/order-view/order-view-sidebar/order-retrieve/order-retrieve.component';
import { SiteviewComponent } from '../_components/site-view/siteview.component';
import { LoginComponent } from '../_login/login.component';
import { DashboardComponent } from '../_dashboard/dashboard.component';
import { OrderNewComponent } from '../_components/order-view/order-view-sidebar/order-new/order-new.component';
import { SiteMigrateComponent } from '../_components/site-view/site-view-sidebar/site-migrate/site-migrate.component';
import { ApplicationPageComponent } from '../application-page/application-page.component';
import { SiteAddSitesComponent } from '../_components/site-view/site-view-sidebar/site-add-sites/site-add-sites.component';
import { OrderItemViewComponent } from '../_components/order-item-view/order-item-view.component';
import { SiteSortComponent } from '../_components/site-view/site-view-sidebar/site-sort/site-sort.component';
import { FindComponent } from '../_components/find/find.component';
import { WorkflowtabComponent } from '../_components/generic/tabs/work-flow-tab/workflowtab.component';
import { MyProfileComponent } from '../_dashboard/my-profile/my-profile.component';
import { AdministrationComponent } from '../_dashboard/administration/administration.component';
import { ServiceSortComponent } from '../_components/service-view/service-view-navbar/service-sort/service-sort.component';
import { ServiceNocetmsDataComponent } from '../_components/service-view/service-view-navbar/service-nocetms-data/service-nocetms-data.component';
import { ServiceCoiocCircuitsComponent } from '../_components/service-view/service-view-navbar/service-coioc-circuits/service-coioc-circuits.component';
import { ServiceRetrieveComponent } from '../_components/service-view/service-view-navbar/service-retrieve/service-retrieve.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'application', component: ApplicationPageComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'my-profile', component: MyProfileComponent },
  { path: 'administration', component: AdministrationComponent },
  { path: 'siteview', component: SiteviewComponent },
  { path: 'orderview', component: OrderViewComponent },
  { path: 'serviceview', component: ServiceViewComponent },
  { path: 'find', component: FindComponent },
  { path: 'orderRetrieve', component: OrderRetrieveComponent },
  { path: 'siteRetrieve', component: SiteRetrieveComponent },
  { path: 'orderNew', component: OrderNewComponent},
  { path: 'siteMigrate', component: SiteMigrateComponent },
  { path: 'siteAdd', component: SiteAddSitesComponent },
  { path: 'orderItemView', component: OrderItemViewComponent },
  { path: 'siteSort', component: SiteSortComponent },
  { path: 'serviceSort', component: ServiceSortComponent },
  { path: 'serviceNoEtmsData', component: ServiceNocetmsDataComponent },
  { path: 'servicecoCircuits', component: ServiceCoiocCircuitsComponent },
  { path: 'serviceRetrieve', component: ServiceRetrieveComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes,
      { useHash: true })
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }