export interface LoginResultModel {
    token: string;
    error: string;
  }
  